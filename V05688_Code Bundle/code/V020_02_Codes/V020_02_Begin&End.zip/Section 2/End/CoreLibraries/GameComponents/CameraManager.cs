﻿using System.Collections.Generic;
using System.Linq;
using Camera;
using Core.Helpers;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using System;

namespace GameComponents
{

	/// <summary>
	/// This is a game component that implements IUpdateable.
	/// </summary>
	public class CameraManager : DrawableGameComponent
	{
		private static eCameraType currentCamera = eCameraType.Rotating;
		private static Dictionary<eCameraType, ICamera> cameras = new Dictionary<eCameraType, ICamera>();


		public CameraManager()
			: base(SharedResources.Game)
		{
			// TODO: Construct any child components here

		}

		/// <summary>
		/// Allows the game component to perform any initialization it needs to before starting
		/// to run.  This is where it can query for any required services and load content.
		/// </summary>
		public override void Initialize()
		{
			base.Initialize();
		}


		/// <summary>
		/// Allows the game component to update itself.
		/// </summary>
		/// <param name="gameTime">Provides a snapshot of timing values.</param>
		public override void Update(GameTime gameTime)
		{
			ActiveCamera.Update();

			// Toggle the state of the camera.
			if (SharedResources.KeyboardPressedAndReleased(Keys.Tab) ||
				(SharedResources.CurrentGamePadState.Buttons.LeftShoulder == ButtonState.Pressed))
			{
				if ((byte)currentCamera + 1 >= System.Enum.GetNames(typeof(eCameraType)).Count())
				{ currentCamera = (eCameraType)0; }
				else { currentCamera = (eCameraType)((byte)currentCamera + 1); }
			}

			base.Update(gameTime);
		}

		public override void Draw(GameTime gameTime)
		{
			var sb = SharedResources.SpriteBatch;
			sb.Begin();
			sb.DrawString(SharedResources.DebugFont, String.Format("{0} : {1}", currentCamera.ToString(), ActiveCamera.Position.ToString()), new Vector2(10, 10), Color.Black);
			sb.End();
			base.Draw(gameTime);
		}


		public static ICamera ActiveCamera
		{
			get
			{
				return cameras[currentCamera];
			}
		}

		public void Add(ICamera cam)
		{
			cameras.Add(cam.Type, cam);
		}
	}


}

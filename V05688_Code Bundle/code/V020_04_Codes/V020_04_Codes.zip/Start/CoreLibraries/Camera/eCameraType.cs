﻿
namespace Camera
{
	public enum eCameraType
	{
		Rotating
	}
}

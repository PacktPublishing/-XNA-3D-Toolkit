﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Core;
using Core.Helpers;

namespace Camera.Stategies
{



	public class FirstPersonCamera : CameraBase, IHandlesInput, ICamera
	{

		private Vector3 headOffset;

		public FirstPersonCamera(INoun target, Vector3 position)
			: base(target, position, eCameraType.FirstPerson)
		{

		}

		public new void Update()
		{
			Matrix rotationMatrix = Matrix.CreateFromQuaternion(target.Rotation);


			//// Transform the head offset so the camera is positioned properly relative to the avatar.
			//Vector3 headOffset = Vector3.Transform(this.headOffset, rotationMatrix);

			//// Calculate the camera's current Position.
			//Vector3 cameraPosition = this.target.Position + headOffset;

			//// Create a vector pointing the direction the camera is facing.
			//Vector3 transformedReference = Vector3.Transform(this.Position, rotationMatrix);

			// Calculate the Position the camera is looking at.
			Vector3 cameraLookat = target.Forward + target.Position;

			// Set up the View matrix and Projection matrix.

			View = Matrix.CreateLookAt(target.Position, target.Position + target.Forward, target.Up);

			Viewport viewport = SharedResources.GraphicsDevice.Viewport;
			float aspectRatio = (float)viewport.Width / (float)viewport.Height;

			this.projection = Matrix.CreatePerspectiveFieldOfView(CameraBase.viewAngle, aspectRatio, 1, 1000);
			base.Update();
		}


		public void HandleInput()
		{
			// This camera is not controlled
		}
	}
}



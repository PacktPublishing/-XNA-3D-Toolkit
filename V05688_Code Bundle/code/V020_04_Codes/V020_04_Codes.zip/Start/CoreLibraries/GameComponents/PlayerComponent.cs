﻿using Core;
using Core.Helpers;
using Microsoft.Xna.Framework;

namespace GameComponents
{
	public class PlayerComponent : DrawableGameComponent, IHandlesInput
	{
		public Noun Noun = new Noun();

		public PlayerComponent()
			: base(SharedResources.Game)
		{

		}

		public void HandleInput()
		{
			throw new System.NotImplementedException();
		}

	}

}

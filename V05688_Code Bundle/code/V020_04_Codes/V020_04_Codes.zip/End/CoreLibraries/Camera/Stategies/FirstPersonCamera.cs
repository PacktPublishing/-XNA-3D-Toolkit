﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Core;
using Core.Helpers;

namespace Camera.Stategies
{



	public class FirstPersonCamera : CameraBase, IHandlesInput, ICamera
	{
		new IPlayer player;

		public FirstPersonCamera(IPlayer player, Vector3 position)
			: base(null, position, eCameraType.FirstPerson)
		{
			this.player = player;
		}

		public new void Update()
		{
			Matrix rotationMatrix = Matrix.CreateFromQuaternion(this.player.Rotation + this.player.Head.Rotation);

			// Calculate the Position the camera is looking at.
			Vector3 cameraLookat = this.player.Head.Forward + this.player.Head.Position;

			// Set up the View matrix and Projection matrix.

			View = Matrix.CreateLookAt(this.player.Head.Position, this.player.Head.Position + this.player.Head.Forward, this.player.Up);

			Viewport viewport = SharedResources.GraphicsDevice.Viewport;
			float aspectRatio = (float)viewport.Width / (float)viewport.Height;

			this.projection = Matrix.CreatePerspectiveFieldOfView(CameraBase.viewAngle, aspectRatio, 1, 1000);
			base.Update();
		}


		public void HandleInput()
		{
			// This camera is not controlled
		}
	}
}



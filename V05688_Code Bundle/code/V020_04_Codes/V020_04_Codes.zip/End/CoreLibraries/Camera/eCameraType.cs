﻿
namespace Camera
{
	public enum eCameraType:byte
	{
		Rotating = 0,
		Orthographic,
		Chase,
		FirstPerson,
		ThirdPerson,
	}
}

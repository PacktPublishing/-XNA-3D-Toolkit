﻿
namespace Core
{
	public interface IUpdate
	{
		void Update();
	}
}

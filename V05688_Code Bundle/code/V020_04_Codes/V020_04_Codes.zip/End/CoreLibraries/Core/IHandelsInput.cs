﻿
namespace Core
{
	public interface IHandlesInput
	{
		void HandleInput();
	}
}

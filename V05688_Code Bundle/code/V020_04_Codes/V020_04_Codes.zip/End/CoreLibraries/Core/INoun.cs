﻿using Microsoft.Xna.Framework;

namespace Core
{

	public interface INoun
	{
		/// <summary>
		/// A transform matrix describing the
		/// current position Scaling Position and Rotation.
		/// </summary>
		Matrix Transform { get; set; }
		/// <summary>
		/// A Quaternion describing the
		/// current Rotation of the object.
		/// </summary>
		Quaternion Rotation { get; set; }
		/// <summary>
		/// The position of the object
		/// </summary>
		Vector3 Position { get; set; }

		Vector3 Up { get; }
		Vector3 Forward { get; }
		Vector3 Right { get; }
	}
}

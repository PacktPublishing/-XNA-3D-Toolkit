﻿using System;
using System.Threading;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Core.Helpers.Interfaces;

namespace Core.Helpers
{
	public static class SharedResources
	{
		static GamePadState cgps, pgps;
		static KeyboardState ckbs, pkbs;
		static GameTime gt = new GameTime();

		static ContentManager cm;
		static GraphicsDevice gd;
		static GraphicsDeviceManager gdm;
		static Game game;
		static SpriteBatch sb;

		static Random r = new Random();

		public static GamePadState CurrentGamePadState
		{
			get { return SharedResources.cgps; }
			set { SharedResources.cgps = value; }
		}

		public static KeyboardState PreviousKeyboardState
		{
			get { return SharedResources.pkbs; }
			set { SharedResources.pkbs = value; }
		}

		public static KeyboardState CurrentKeyboardState
		{
			get { return SharedResources.ckbs; }
			set { SharedResources.ckbs = value; }
		}

		public static GameTime GameTime
		{
			get { return SharedResources.gt; }
			set { SharedResources.gt = value; }
		}

		public static Microsoft.Xna.Framework.Game Game
		{
			get { return SharedResources.game; }
			set { SharedResources.game = value; }
		}
		public static GraphicsDeviceManager GraphicsDeviceManager
		{
			get { return SharedResources.gdm; }
			set { SharedResources.gdm = value; }
		}
		public static SpriteBatch SpriteBatch
		{
			get { return SharedResources.sb; }
			set { SharedResources.sb = value; }
		}

		public static Random R
		{
			get { return SharedResources.r; }
			set { SharedResources.r = value; }
		}


		public static GraphicsDevice GraphicsDevice
		{
			get { return SharedResources.gd; }
			set { SharedResources.gd = value; }
		}
		/// <summary>
		///  Must Not Try to get this before OnLoad
		/// </summary>
		public static ContentManager ContentManager
		{
			get
			{
				if (cm == null)
				{
					cm = game.Content;
				}
				return cm;
			}
			set { cm = value; }
		}

		public static void OnCreate(Microsoft.Xna.Framework.Game xnaGame)
		{
			xnaGame.Content.RootDirectory = "Content";
			gdm = new GraphicsDeviceManager(xnaGame);
			game = xnaGame;
			R = new Random();
		}
		public static void OnInitialize(Microsoft.Xna.Framework.Game xnaGame)
		{
			ckbs = pkbs = Keyboard.GetState();
			cgps = GamePad.GetState(PlayerIndex.One);
		}
		public static void OnLoadContent(IGame game)
		{
			gd = game.xnaGame.GraphicsDevice;
			ContentManager = game.xnaGame.Content;
			sb = new SpriteBatch(GraphicsDevice);
			DebugFont = ContentManager.Load<SpriteFont>("MyFont");
		}

		public static void OnBeginUpdate(GameTime gameTime)
		{
			ckbs = Keyboard.GetState();
			gt = gameTime;

		}
		public static void OnEndUpdate()
		{
			pkbs = ckbs;
		}

		public static SpriteFont DebugFont { get; set; }

		public static bool KeyboardPressedAndReleased(Keys key)
		{
			return ckbs.IsKeyDown(key) && pkbs.IsKeyUp(key);
		}

		public static void OnUnLoadContent(IGame game)
		{
		}

		public static void OnUpdate(IGame game)
		{
			// Allows the game to exit
			if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
			{ game.Exit(); }
		}

		public static void Draw(IGame game)
		{
			GraphicsDevice.Clear(Color.CornflowerBlue);

		}
	}
}


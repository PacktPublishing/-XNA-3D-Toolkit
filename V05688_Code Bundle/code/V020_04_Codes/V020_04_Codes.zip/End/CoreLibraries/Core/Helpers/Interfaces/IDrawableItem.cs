﻿using Microsoft.Xna.Framework;

namespace Core.Helpers.Interfaces
{
	public interface IDrawableItem
	{
		void LoadContent();
		void UnLoadContent();
		void Draw(Matrix viewMatrix, Matrix projectionMatrix);
	}
}

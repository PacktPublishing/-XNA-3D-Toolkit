﻿using Microsoft.Xna.Framework;

namespace Core.Helpers.Interfaces
{

	public interface IGame
	{
		Game xnaGame { get; set; }
		void CreateAssets();
		void Exit();
	}
}
	

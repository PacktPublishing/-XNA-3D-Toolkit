﻿using Core.Helpers.Interfaces;
using Microsoft.Xna.Framework;

namespace Core
{
	public interface IPlayer : INoun, IHandlesInput, IDraw, IUpdate
	{
		INoun Head { get; set; }
	}
}

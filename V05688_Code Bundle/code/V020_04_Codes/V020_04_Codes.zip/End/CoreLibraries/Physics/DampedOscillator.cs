using System;
using Microsoft.Xna.Framework;
using Core;
using Core.Helpers;
using Physics.SystemDefinitions;

namespace Physics
{
	public class DampedOscillator : ITwoBodySystem, IControlMovement
	{
		private float stiffness = 1800.0f;
		private float damping = 600.0f;
		private float mass = 50.0f;
		private Vector3 equilibriumPosition;
		private Vector3 velocity;


		private INoun immobileBody;
		private INoun mobileBody;

		/// <summary>
		/// Physics coefficient which controls the influence of the objects's position
		/// over the spring force. The stiffer the spring, the closer it will stay to
		/// the equilibriumPosition.
		/// </summary>
		public float Stiffness
		{
			get { return stiffness; }
			set { stiffness = value; }
		}

		/// <summary>
		/// Physics coefficient which approximates internal friction of the spring.
		/// Sufficient damping will prevent the spring from oscillating infinitely.
		/// </summary>
		public float Damping
		{
			get { return damping; }
			set { damping = value; }
		}
		/// <summary>
		/// Mass of the body. Heavier objects require stiffer springs with less
		/// damping to move at the same rate as lighter objects.
		/// </summary>
		public float Mass
		{
			get { return mass; }
			set { mass = value; }
		}
		/// <summary>
		/// The attachment of the Oscillator
		/// </summary>
		public INoun ImmobileBody
		{
			get { return immobileBody; }
			set { immobileBody = value; }
		}
		/// <summary>
		/// The object that this Oscillator Controls
		/// </summary>
		public INoun MobileBody
		{
			get { return mobileBody; }
			set { mobileBody = value; }
		}
		/// <summary>
		/// Velocity of object.
		/// </summary>
		public Vector3 Velocity
		{
			get { return velocity; }
		}
		
		/// <summary>
		/// The Vector that acts as the spring
		/// </summary>
		public Vector3 EquilibriumPosition
		{
			get { return equilibriumPosition; }
			set { equilibriumPosition = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		/// <param name="immobileBody">the position that the spring is attached to</param>
		/// <param name="mobileBody">the object that this spring controlls</param>
		/// <param name="equilibriumPosition">the length of the spring
		/// <para> this should usually be a multiple of a unit vector,
		/// but there are times you may want the spring to behave differently...</para></param>
		public DampedOscillator(INoun immobileBody, INoun mobileBody, Vector3 equilibriumPosition )
		{
			this.immobileBody = immobileBody;
			this.mobileBody = mobileBody;
			this.equilibriumPosition = equilibriumPosition;
		}
		
		/// <summary>
		/// Forces camera to be at desired position and to stop moving. The is useful
		/// when the chased object is first created or after it has been teleported.
		/// Failing to call this after a large change to the chased object's position
		/// will result in the camera quickly flying across the world.
		/// </summary>
		public void Reset()
		{
			
			// Stop motion
			velocity = Vector3.Zero;
			// Force desired position
			mobileBody.Position = mobileBody.Position + equilibriumPosition;
			Update();
		}

		/// <summary>
		/// Animates the camera from its current position towards the desired offset
		/// behind the chased object. The camera's animation is controlled by a simple
		/// physical spring attached to the camera and anchored to the desired position.
		/// </summary>
		public void Update()
		{

			float elapsed = (float)SharedResources.GameTime.ElapsedGameTime.TotalSeconds;

			// Calculate spring force
			Vector3 stretch = mobileBody.Position - ImmobileBody.Position  - equilibriumPosition;
			Vector3 force = -stiffness * stretch - damping * velocity;

			// Apply acceleration
			Vector3 acceleration = force / mass;
			velocity += acceleration * elapsed;

			// Apply velocity
			mobileBody.Position += velocity * elapsed;

		}


	}
}

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Core
{
	public class Greeting : DrawableGameComponent
	{
		SpriteFont font;
		SpriteBatch sb;

		public Greeting(Game baseGame):base(baseGame){}
		protected override void LoadContent()
		{
			sb = new SpriteBatch(Game.GraphicsDevice);
			font = Game.Content.Load<SpriteFont>("MyFont");
			base.LoadContent();
		}

		public override void Draw(GameTime gameTime)
		{
			sb.Begin();
			sb.DrawString(font, "Hello from your common Code", new Vector2(32, 32), Color.Red);
			sb.End();
			base.Draw(gameTime);
		}
	}
}

﻿using Core;
using Core.Helpers;
using Microsoft.Xna.Framework;

namespace GameComponents
{
	public class PlayerComponent : DrawableGameComponent, IHandlesInput
	{
		private IPlayer player;

		public IPlayer Player
		{
			get { return player; }
			set { player = value; }
		}

		public PlayerComponent(IPlayer plyr)
			: base(SharedResources.Game)
		{
			this.player = plyr;
		}

		public void HandleInput()
		{
			player.HandleInput();
		}
		protected override void LoadContent()
		{
			player.LoadContent();
			base.LoadContent();
		}
		public override void Draw(GameTime gameTime)
		{
			player.Draw(CameraManager.ActiveCamera.View, CameraManager.ActiveCamera.Projection);
			base.Draw(gameTime);
		}
		public override void Update(GameTime gameTime)
		{
			player.Update();
			base.Update(gameTime);
		}
		protected override void UnloadContent()
		{
			player.UnLoadContent();
			base.UnloadContent();
		}

	}

}

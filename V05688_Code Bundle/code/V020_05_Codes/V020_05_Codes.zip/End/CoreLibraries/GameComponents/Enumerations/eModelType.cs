﻿
namespace GameComponents.Enumerations
{
	public enum eModelType
	{
		Simple,
		Instanced,
		Cube,
	}
}

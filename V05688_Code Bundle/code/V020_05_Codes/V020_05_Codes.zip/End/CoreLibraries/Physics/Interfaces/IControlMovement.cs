﻿
namespace Physics
{
	public interface IControlMovement
	{
		void Update();
	}
}

﻿using Microsoft.Xna.Framework;

namespace Core.Helpers.Interfaces
{
	public interface IDraw
	{
		void LoadContent();
		void UnLoadContent();
		void Draw(Matrix viewMatrix, Matrix projectionMatrix);
	}
}

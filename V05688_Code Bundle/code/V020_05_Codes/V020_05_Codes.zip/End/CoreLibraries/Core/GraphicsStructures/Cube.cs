﻿using Core.Helpers;
using Core.Helpers.Interfaces;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Core.GraphicsStructures
{
	public class Cube : IDraw
	{
		VertexBuffer vb;
		IndexBuffer ib;
		BasicEffect effect;
		public ModelInfo Info;

		public Cube(Vector3 position, Texture2D texture)
		{
			//Only call this after you've created your graphics Device (after Load Content)
			effect = new BasicEffect(SharedResources.GraphicsDevice)
			{
				TextureEnabled = true,
				Texture = texture,
			};

			Info = new ModelInfo(Matrix.CreateTranslation(position),
				new BoundingBox(new Vector3(-1.0f, -1.0f, -1.0f) + position, new Vector3(1.0f, 1.0f, 1.0f) + position));

			Vector2 topLeft = new Vector2(0.0f, 0.0f);
			Vector2 topRight = new Vector2(1.0f, 0.0f);
			Vector2 bottomLeft = new Vector2(0.0f, 1.0f);
			Vector2 bottomRight = new Vector2(1.0f, 1.0f);

			

			// Initialize the Rectangle's data (Do not need vertex colors)
			VertexPositionTexture[] boxData = new VertexPositionTexture[]
			{
				// Front Surface
				new VertexPositionTexture(new Vector3(-1.0f, -1.0f, 1.0f)+position,bottomLeft),
				new VertexPositionTexture(new Vector3(-1.0f, 1.0f, 1.0f)+position,topLeft), 
				new VertexPositionTexture(new Vector3(1.0f, -1.0f, 1.0f)+position,bottomRight),
				new VertexPositionTexture(new Vector3(1.0f, 1.0f, 1.0f)+position,topRight),  

				// Front Surface
				new VertexPositionTexture(new Vector3(1.0f, -1.0f, -1.0f)+position,bottomLeft),
				new VertexPositionTexture(new Vector3(1.0f, 1.0f, -1.0f)+position,topLeft), 
				new VertexPositionTexture(new Vector3(-1.0f, -1.0f, -1.0f)+position,bottomRight),
				new VertexPositionTexture(new Vector3(-1.0f, 1.0f, -1.0f)+position,topRight), 

				// Left Surface
				new VertexPositionTexture(new Vector3(-1.0f, -1.0f, -1.0f)+position,bottomLeft),
				new VertexPositionTexture(new Vector3(-1.0f, 1.0f, -1.0f)+position,topLeft),
				new VertexPositionTexture(new Vector3(-1.0f, -1.0f, 1.0f)+position,bottomRight),
				new VertexPositionTexture(new Vector3(-1.0f, 1.0f, 1.0f)+position,topRight),

				// Right Surface
				new VertexPositionTexture(new Vector3(1.0f, -1.0f, 1.0f)+position,bottomLeft),
				new VertexPositionTexture(new Vector3(1.0f, 1.0f, 1.0f)+position,topLeft),
				new VertexPositionTexture(new Vector3(1.0f, -1.0f, -1.0f)+position,bottomRight),
				new VertexPositionTexture(new Vector3(1.0f, 1.0f, -1.0f)+position,topRight),

				// Top Surface
				new VertexPositionTexture(new Vector3(-1.0f, 1.0f, 1.0f)+position,bottomLeft),
				new VertexPositionTexture(new Vector3(-1.0f, 1.0f, -1.0f)+position,topLeft),
				new VertexPositionTexture(new Vector3(1.0f, 1.0f, 1.0f)+position,bottomRight),
				new VertexPositionTexture(new Vector3(1.0f, 1.0f, -1.0f)+position,topRight),

				// Bottom Surface
				new VertexPositionTexture(new Vector3(-1.0f, -1.0f, -1.0f)+position,bottomLeft),
				new VertexPositionTexture(new Vector3(-1.0f, -1.0f, 1.0f)+position,topLeft),
				new VertexPositionTexture(new Vector3(1.0f, -1.0f, -1.0f)+position,bottomRight),
				new VertexPositionTexture(new Vector3(1.0f, -1.0f, 1.0f)+position,topRight),
			};
			short[] boxIndices = new short[] { 
				0, 1, 2, 2, 1, 3,   
				4, 5, 6, 6, 5, 7,
				8, 9, 10, 10, 9, 11, 
				12, 13, 14, 14, 13, 15, 
				16, 17, 18, 18, 17, 19,
				20, 21, 22, 22, 21, 23
			};

			vb = new VertexBuffer(SharedResources.GraphicsDevice, VertexPositionTexture.VertexDeclaration, 24, BufferUsage.WriteOnly);
			ib = new IndexBuffer(SharedResources.GraphicsDevice, IndexElementSize.SixteenBits, 36, BufferUsage.WriteOnly);

			vb.SetData<VertexPositionTexture>(boxData);
			ib.SetData<short>(boxIndices);
			boxData = null;
			boxIndices = null;
		}

		public void LoadContent()
		{
		}

		public void UnLoadContent()
		{
		}

		public void Draw(Matrix viewMatrix, Matrix projectionMatrix)
		{
			effect.View = viewMatrix;
			effect.Projection = projectionMatrix;
			effect.CurrentTechnique.Passes[0].Apply();
			SharedResources.GraphicsDevice.SetVertexBuffer(vb);
			SharedResources.GraphicsDevice.Indices = ib;
			SharedResources.GraphicsDevice.DrawIndexedPrimitives(PrimitiveType.TriangleList, 0, 0, 24, 0, 12);
		}
	}
}

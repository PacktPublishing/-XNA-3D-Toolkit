﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Core.Helpers.Interfaces;
using Core.Helpers;
using Core.GraphicsStructures;

namespace Core.Collections
{
	public class InstancedModel:IDraw
	{
		Model model;

		public Model Model
		{
			get { return model; }
			set { model = value; }
		}
		Matrix[] modelBones = new Matrix[0];

		public Matrix[] ModelBones
		{
			get { return modelBones; }
			set { modelBones = value; }
		}
		ModelInfo[] instances = new ModelInfo[0];

		public InstancedModel(string path)
		{
			this.LoadContent(path);
		}

		public ModelInfo[] Instances
		{
			get { return instances; }
			set { instances = value; }
		}
		public InstancedModel(string path, Matrix[] transforms)
		{
			this.LoadContent(path);
			this.instances = new ModelInfo[transforms.Length];
			for (int i = 0; i < this.instances.Length; i++) 
			{
				this.instances[i] = new ModelInfo(transforms[i], ModelInfoHelper.ConstructUnitBounds(transforms[i].Translation));
			}
			
		}



		public void AddInstance(Matrix transform)
		{
			//Can optimize this so that all models have the same bounding box equal to the size of the extent of the collection.
			// however this may not always be optimal.
			ModelInfo[] temp = (ModelInfo[])instances.Clone();
			this.instances = new ModelInfo[temp.Length + 1];
			for (int i = 0; i < temp.Length; i++) { this.instances[i] = temp[i]; }
			this.instances[temp.Length] = new ModelInfo(transform, ModelInfoHelper.ConstructUnitBounds(transform.Translation));
			
		}
		public void LoadContent(string path)
		{
			model = SharedResources.ContentManager.Load<Model>(path);
			modelBones = new Matrix[model.Bones.Count];
			model.CopyAbsoluteBoneTransformsTo(modelBones);
		}

		public void UnLoadContent()
		{
			//Let the content manager handle this
		}

		public void Draw(Matrix viewMatrix, Matrix projectionMatrix)
		{
			this.DrawModelHardwareInstancing(viewMatrix, projectionMatrix);
		}

		public void LoadContent()
		{
			throw new NotImplementedException();
		}

		public Matrix[] InstancesTransforms { get { return instances.Select(e => e.World).ToArray(); } }
	}
}

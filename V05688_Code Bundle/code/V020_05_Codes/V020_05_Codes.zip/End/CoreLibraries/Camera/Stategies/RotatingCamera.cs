﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Core;
using Core.Helpers;

namespace Camera.Strategies
{
	public class RotatingCamera : CameraBase, ICamera, IHandlesInput
	{
		public RotatingCamera() : base(null, Vector3.Zero, eCameraType.Rotating) { Position = new Vector3(0f, 0.5f, 0f); }

		void ICamera.Update()
		{
			// Figure out our camera location. We spin around the origin based on time.
			float angle = (float)SharedResources.GameTime.TotalGameTime.TotalSeconds;
			Position = new Vector3(
				(float)Math.Cos(angle * .5f) * 12f,
				MathHelper.Clamp(Position.Y + 0.01f, -20, 20),
			(float)Math.Sin(angle * .5f) * 12f);

			// Construct our view and projection matrices
			view = Matrix.CreateLookAt(Position, Vector3.Zero, Vector3.Up);
			projection = Matrix.CreatePerspectiveFieldOfView(
				MathHelper.PiOver4, SharedResources.GraphicsDevice.Viewport.AspectRatio, .1f, 1000f);
			base.Update();
		}

		public void HandleInput()
		{
			//not used
		}
	}
}

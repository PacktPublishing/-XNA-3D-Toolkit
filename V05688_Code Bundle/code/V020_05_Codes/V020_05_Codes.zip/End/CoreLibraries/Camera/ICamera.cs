﻿
using Microsoft.Xna.Framework;

namespace Camera
{
	public interface ICamera
	{
		Matrix Projection { get; set; }
		Matrix View { get; set; }
		Vector3 Position { get; set; }
		BoundingFrustum Frustum { get; }
		eCameraType Type { get; }

		void Update();
	}
}

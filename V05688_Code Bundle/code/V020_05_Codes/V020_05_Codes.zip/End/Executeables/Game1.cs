using System;
using Core.Helpers;
using Core.Helpers.Interfaces;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System.Collections.Generic;
using GameComponents;
#if DEBUG
using System.Linq;
using Microsoft.ShapeRenderingSample;
using Microsoft.CollisionSample;
using Microsoft.VertexLightingSample;
using GraphicsDebugger;
using Camera;
using GraphicsDebugger.GameComponentExtensions;
using Camera.Strategies;
using Core.Tokens;
using Camera.Stategies;
using Core.Collections;
using GameComponents.Enumerations;
#endif

namespace StarterGame
{
	/// <summary>
	/// This is the main type for your game
	/// </summary>
	public class StarterGame : Game, IGame
	{
		
#if DEBUG
		private SampleGrid grid;
#endif
		CameraManager cameraManager;
		PlayerComponent player;


		public StarterGame()
		{

			SharedResources.OnCreate(this);
			cameraManager = new CameraManager();
			//player = new PlayerComponent(new PlayerToken());
			player = new PlayerComponent(new SnowmanToken());
			this.Components.Add(cameraManager);
			this.Components.Add(player);
			this.Components.Add(new DrawOrderManager());
#if DEBUG
			this.Components.Add(new FrameRateCounter(this));
#endif
			Content.RootDirectory = "GameContent(HiDef)";
		}

		/// <summary>
		/// Allows the game to perform any initialization it needs to before starting to run.
		/// This is where it can query for any required services and load any non-graphic
		/// related content.  Calling base.Initialize will enumerate through any components
		/// and initialize them as well.
		/// </summary>
		protected override void Initialize()
		{
#if DEBUG
			DebugShapeRenderer.Initialize(this.GraphicsDevice);
#endif

			SharedResources.OnInitialize(this);
			// TODO: Add your initialization logic here
			


			base.Initialize();
		}

		/// <summary>
		/// LoadContent will be called once per game and is the place to load
		/// all of your content.
		/// </summary>
		protected override void LoadContent()
		{
			SharedResources.OnLoadContent(this);

			cameraManager.Add(new RotatingCamera());
			cameraManager.Add(new OrthographicCamera(player.Player, new Vector3(3, 3, 3)));
			cameraManager.Add(new ChaseCamera(player.Player));
			cameraManager.Add(new FirstPersonCamera(player.Player, Vector3.Forward));
			cameraManager.Add(new ThirdPersonCamera(player.Player, 3));

			// TODO: use this.Content to load your game content here
			Matrix half = new Matrix(
					0.5f, 0f, 0f, 0f,
					  0f, 0.5f, 0f, 0f,
					  0f, 0f, 0.5f, 0f,
					  0f, 0f, 0f, 1f);
			List<Tuple<int, Matrix>> temp = new List<Tuple<int, Matrix>>();
			int counter = -1;
			for (int y = -2; y < 2; y++)
			{
				counter = -1;
				for (int i = 0; i < 5; i++)
				{
					temp.Add(new Tuple<int, Matrix>(i, half * Matrix.CreateTranslation(new Vector3(2.5f * counter, y, 0f))));
					counter++;
				}
			}
			List<Matrix> instanceLocations = new List<Matrix>();


			for (int x = -15; x < -10; x++)
			{
				for (int y = -5; y < 5; y++)
				{
					for (int z = -5; z < 5; z++)
					{
						instanceLocations.Add(half * Matrix.CreateTranslation(new Vector3(
							x + 0.1f * instanceLocations.Count,
							y + 0.1f * instanceLocations.Count,
							z + 0.1f * instanceLocations.Count)));
					}
				}
			}
			//DOn't use this syntax in your XBOX game it produces a lot of garbage
			var coneLocations = temp.Where(e => e.Item1 == 0).Select(e => e.Item2).ToArray();
			var cubeLocations = temp.Where(e => e.Item1 == 1).Select(e => e.Item2).ToArray();
			var cylindarLocations = temp.Where(e => e.Item1 == 2).Select(e => e.Item2).ToArray();
			var highLocations = temp.Where(e => e.Item1 == 3).Select(e => e.Item2).ToArray();
			var lowLocations = temp.Where(e => e.Item1 == 4).Select(e => e.Item2).ToArray();

			DrawOrderManager.Add(eModelType.Simple, "Cone", "Cone", coneLocations);
			DrawOrderManager.Add(eModelType.Simple, "Cube", "Cube", cubeLocations);
			DrawOrderManager.Add(eModelType.Simple, "Cylinder", "Cylinder", cylindarLocations);
			DrawOrderManager.Add(eModelType.Simple, "SphereHighPoly", "SphereHighPoly", highLocations);
			DrawOrderManager.Add(eModelType.Simple, "SphereLowPoly", "SphereLowPoly", lowLocations);
			DrawOrderManager.Add(eModelType.Instanced, "Cone", "InstancedModels/Cone", instanceLocations.ToArray());
			DrawOrderManager.Add(eModelType.Cube, "Green", "GraphicsSupportItems/GreenPixel", new Matrix[] { Matrix.CreateTranslation(new Vector3(2, 3, 2)) });
			DrawOrderManager.Add(eModelType.Cube, "Default", null, new Matrix[] { Matrix.CreateTranslation(new Vector3(2, 0, 2)) });
			DrawOrderManager.Add(eModelType.Cube, "Metalic", null, new Matrix[] { Matrix.CreateTranslation(new Vector3(2, -2, 2)) });
			DrawOrderManager.Add(eModelType.Cube, "Psychadelic", null, new Matrix[] { Matrix.CreateTranslation(new Vector3(2, -4, 2)) });


#if DEBUG
			DebugShapeRenderer.AddBoundingBox(new BoundingBox(new Vector3(-2, -2, -2), new Vector3(2, 2, 2)), Color.RosyBrown, 30);

			//Set up the reference grid
			grid = new SampleGrid();
			grid.GridColor = Color.LimeGreen;
			grid.GridScale = 1.0f;
			grid.GridSize = 32;
			grid.LoadGraphicsContent();
			//Set the grid to draw on the x/z plane around the origin
			grid.WorldMatrix = Matrix.Identity;
#endif

		}

		/// <summary>
		/// UnloadContent will be called once per game and is the place to unload
		/// all content.
		/// </summary>
		protected override void UnloadContent()
		{
		
			SharedResources.OnUnLoadContent(this);
			// TODO: Unload any non ContentManager content here
		}

		/// <summary>
		/// Allows the game to run logic such as updating the world,
		/// checking for collisions, gathering input, and playing audio.
		/// </summary>
		/// <param name="gameTime">Provides a snapshot of timing values.</param>
		protected override void Update(GameTime gameTime)
		{
			SharedResources.OnBeginUpdate(gameTime);
		
			SharedResources.OnUpdate(this);
			// TODO: Add your update logic here
#if DEBUG

			grid.ProjectionMatrix = CameraManager.ActiveCamera.Projection;
			grid.ViewMatrix = CameraManager.ActiveCamera.View;
#endif


			base.Update(gameTime);
			SharedResources.OnEndUpdate();
		}

		/// <summary>
		/// This is called when the game should draw itself.
		/// </summary>
		/// <param name="gameTime">Provides a snapshot of timing values.</param>
		protected override void Draw(GameTime gameTime)
		{
			SharedResources.Draw(this);
			//the SpriteBatch added below to draw the current technique name
			//is changing some needed render states, so they are reset here.
			this.GraphicsDevice.DepthStencilState = DepthStencilState.Default;
			//draw the reference grid so it's easier to get our bearings
#if DEBUG
			grid.Draw();
			Gimbal.Instance.Draw();
			cameraManager.DrawCameras();

			var activeCamera = CameraManager.ActiveCamera;
			DebugShapeRenderer.Draw(gameTime, activeCamera.View, activeCamera.Projection);
#endif
			// TODO: Add your drawing code here
				DebugShapeRenderer.AddBoundingBox(new BoundingBox(new Vector3(4, 0, 4), new Vector3(5, 1, 5)), Color.Violet);
			var bounding = DrawOrderManager.GetBoundingBoxes(eModelType.Cube);
			foreach(var box in bounding)
			{
				DebugShapeRenderer.AddBoundingBox(box, Color.Violet);
			}
			
			bounding = DrawOrderManager.GetBoundingBoxes(eModelType.Instanced);
			foreach (var box in bounding)
			{
				DebugShapeRenderer.AddBoundingBox(box, Color.Black);
			}
			
			bounding = DrawOrderManager.GetBoundingBoxes(eModelType.Simple);
			foreach (var box in bounding)
			{
				DebugShapeRenderer.AddBoundingBox(box, Color.DarkOliveGreen);
			}
			SharedResources.SpriteBatch.Begin();

#if DEBUG
			SharedResources.SpriteBatch.DrawString(SharedResources.DebugFont, "Debug", new Vector2(50, 50), Color.Black);
#else
			SharedResources.SpriteBatch.DrawString(SharedResources.DebugFont, "Release", new Vector2(50,50), Color.Black);
#endif
			SharedResources.SpriteBatch.End();

			base.Draw(gameTime);
		}

		public Game xnaGame
		{
			get
			{
				return this;
			}
			set
			{
				throw new NotImplementedException();
			}
		}

		public void CreateAssets()
		{
		}
	}
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using Core.Helpers;
using Core.GraphicsStructures;

namespace Core.Collections
{
	public class SimpleModel
	{
		protected Model model;
		protected Matrix[] modelBones = new Matrix[0];
		protected ModelInfo[] instances = new ModelInfo[0];

		public Model Model
		{
			get { return model; }
			set { model = value; }
		}

		public Matrix[] ModelBones
		{
			get { return modelBones; }
			set { modelBones = value; }
		}

		public SimpleModel(string path)
		{
			this.LoadContent(path);
		}

		public ModelInfo[] Instances
		{
			get { return instances; }
			set { instances = value; }
		}
		public SimpleModel(string path, Matrix[] transforms)
		{
			this.LoadContent(path);
			this.instances = new ModelInfo[transforms.Length];
			for (int i = 0; i < this.instances.Length; i++)
			{
				this.instances[i] = new ModelInfo(transforms[i], ModelInfoHelper.ConstructUnitBounds(transforms[i].Translation)); 
			}
			
		}

		public void AddInstance(Matrix transform)
		{
			ModelInfo[] temp = (ModelInfo[])instances.Clone();
			this.instances = new ModelInfo[temp.Length + 1];
			for (int i = 0; i < temp.Length; i++) { this.instances[i] = temp[i]; }
			this.instances[temp.Length] = new ModelInfo(transform, ModelInfoHelper.ConstructUnitBounds(transform.Translation));
		}
		public void LoadContent(string path)
		{
			model = SharedResources.ContentManager.Load<Model>(path);
			modelBones = new Matrix[model.Bones.Count];
			model.CopyAbsoluteBoneTransformsTo(modelBones);
		}

		public void UnLoadContent()
		{
			//Let the content manager handle this
		}

		public void Draw(Matrix viewMatrix, Matrix projectionMatrix, int index)
		{
			this.model.Draw(viewMatrix, projectionMatrix, this.instances[index].World.Translation, this.instances[index].World);
		}

		public void LoadContent()
		{
			throw new NotImplementedException();
		}
	}
}

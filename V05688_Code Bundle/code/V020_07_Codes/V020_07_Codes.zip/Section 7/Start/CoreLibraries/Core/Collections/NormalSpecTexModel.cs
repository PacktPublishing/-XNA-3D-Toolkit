﻿using System;
using Core.GraphicsStructures;
using Core.Helpers;
using Core.Helpers;
using Core.HLSL;
using Core.HLSL.SupportedShaders;
using Core.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Core.Collections
{
	/// <summary>
	/// Shader that calculates specular from the normal.
	/// </summary>
	public class NormalDiffuseModel:SimpleModel
	{
		string diffuseKey, normalKey;

		public NormalDiffuseModel(string path,  string normalPath, string diffusePath):base(path)
		{
			NormalDiffuseShader.Initialize();


			diffuseKey = diffusePath.GetFileFromPath();
			if (!TextureLibrary.Texture2dCollection.ContainsKey(diffuseKey))
			{
				TextureLibrary.Texture2dCollection.Add(diffuseKey,
				   SharedResources.ContentManager.Load<Texture2D>(diffusePath)
				   );
			}
			normalKey = normalPath.GetFileFromPath();
			if (!TextureLibrary.Texture2dCollection.ContainsKey(normalKey))
			{
				TextureLibrary.Texture2dCollection.Add(normalKey,
					SharedResources.ContentManager.Load<Texture2D>(normalPath)
					);
			}
		}

		public NormalDiffuseModel(string path,  string normalpath, string diffusePath, Matrix[] transforms)
			:this(path,  normalpath, diffusePath)
		{
			this.instances = new ModelInfo[transforms.Length];
			for (int i = 0; i < this.instances.Length; i++)
			{
				this.instances[i] = new ModelInfo(transforms[i], ModelInfoHelper.ConstructUnitBounds(transforms[i].Translation)); 
			}
			
		}

		public new void Draw(Matrix viewMatrix, Matrix projectionMatrix, int index)
		{
			NormalDiffuseShader.Instance.Effect.Parameters["DiffuseTexture"].SetValue(TextureLibrary.Texture2dCollection[diffuseKey]);
			NormalDiffuseShader.Instance.Effect.Parameters["NormalTexture"].SetValue(TextureLibrary.Texture2dCollection[normalKey]);

			// the next 4 fields are inputs to the normal mapping effect, and will be set
			// at load time.  change these to change the light properties to modify
			// the appearance of the model.
			Vector4 lightColor = new Vector4(1, 1, 1, 1);
			Vector4 ambientLightColor = new Vector4(.2f, .2f, .2f, 1);
			float shininess = .3f;
			float specularPower = 4.0f;

			NormalDiffuseShader.Instance.Effect.Parameters["LightColor"].SetValue(lightColor);
			NormalDiffuseShader.Instance.Effect.Parameters["AmbientLightColor"].SetValue(ambientLightColor);
			NormalDiffuseShader.Instance.Effect.Parameters["Shininess"].SetValue(shininess);
			NormalDiffuseShader.Instance.Effect.Parameters["SpecularPower"].SetValue(specularPower);
			this.model.DrawWithShader(viewMatrix, projectionMatrix, this.instances[index].World.Translation, this.instances[index].World, NormalDiffuseShader.Instance);
		}
	}
}

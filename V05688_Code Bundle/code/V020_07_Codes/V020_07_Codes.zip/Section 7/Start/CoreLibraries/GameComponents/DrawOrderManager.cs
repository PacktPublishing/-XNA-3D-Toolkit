﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using GameComponents.Enumerations;
using Microsoft.Xna.Framework.Graphics;
using Core.Collections;
using Core.GraphicsStructures;
using Core.Helpers;
using Camera;

namespace GameComponents
{
	public class DrawOrderManager : DrawableGameComponent
	{
		private new struct DrawOrder
		{
			public eModelType Type;
			public string Key;
			//this will be null in certain cases....
			public int? Index;
			public Vector3 Position;
			public DrawOrder(eModelType type, string key, int? index, Vector3 position)
			{
				this.Type = type;
				this.Key = key;
				this.Index = index;
				this.Position = position;
			}
			public override string ToString()
			{
				return string.Format("{0},{1},{2}", Type.ToString(), Key, Index.HasValue ? Index.Value.ToString() : "null");
			}
		}

		private List<DrawOrder> drawOrder = new List<DrawOrder>();

		private static Dictionary<string, SimpleModel> models = new Dictionary<string, SimpleModel>();
		private static Dictionary<string, InstancedModel> instancedModels = new Dictionary<string, InstancedModel>();
		private static Dictionary<string, Cube> cubes = new Dictionary<string, Cube>();
		private static Dictionary<string, NormalDiffuseModel> normalSpecDiffuseModels = new Dictionary<string, NormalDiffuseModel>();
		
		public static void Add(eModelType type, string assetName, string assetPath)
		{
			switch (type)
			{
				case eModelType.Simple:
					models.Add(assetName, new SimpleModel(assetPath));
					break;
				case eModelType.Instanced:
					instancedModels.Add(assetName, new InstancedModel(assetPath));
					break;
				case eModelType.Cube:
					switch (assetName)
					{
						case "Default":
							cubes.Add(assetName, Cubes.Make(Vector3.Zero, eCubeType.Default));
							break;
						case "Metal":
							cubes.Add(assetName, Cubes.Metalic(Vector3.Zero));
							break;
						case "Psychadelic":
							cubes.Add(assetName, Cubes.Psychadelic(Vector3.Zero));
							break;
						default:
							cubes.Add(assetName, Cubes.Make(Vector3.Zero, assetPath));
							break;
					}
					break;
				case eModelType.NormalSpecDiffuseModel:
					throw new NotSupportedException("NormalSpecDiffuseModel must be created with textures associated use AddNormalSpecDiffuseModel() instead.");
					
				default:
					break;
			}
		}
		public static void Add(eModelType type, string assetName, string assetPath, Matrix[] locations)
		{
			switch (type)
			{
				case eModelType.Simple:
					models.Add(assetName, new SimpleModel(assetPath, locations));
					break;
				case eModelType.Instanced:
					instancedModels.Add(assetName, new InstancedModel(assetPath, locations));
					break;
				case eModelType.Cube:
					switch (assetName)
					{
						case "Default":

							foreach (var matrix in locations)
							{
								cubes.Add(assetName, Cubes.Make(matrix.Translation, eCubeType.Default));
							}
							break;
						case "Metalic":

							foreach (var matrix in locations)
							{
								cubes.Add(assetName, Cubes.Metalic(matrix.Translation));
							}
							break;
						case "Psychadelic":

							foreach (var matrix in locations)
							{
								cubes.Add(assetName, Cubes.Psychadelic(matrix.Translation));
							}
							break;
					}
					break;
				case eModelType.NormalSpecDiffuseModel:
					throw new NotSupportedException("NormalSpecDiffuseModel must be created with textures associated use AddNormalSpecDiffuseModel() instead.");
					
				default:
					break;
			}
		}
		public static void AddNormalDiffuseModel(string assetName, string assetPath, string normalPath, string diffusePath)
		{
			normalSpecDiffuseModels.Add(assetName,
				new NormalDiffuseModel(assetPath, normalPath, diffusePath));
		}
		public static void AddNormalDiffuseModel(string assetName, string assetPath, string normalPath, string diffusePath, Matrix[] locations)
		{
			normalSpecDiffuseModels.Add(assetName,
				new NormalDiffuseModel(assetPath, normalPath, diffusePath, locations));
		}

		public DrawOrderManager()
			: base(SharedResources.Game)
		{
			// TODO: Construct any child components here

		}

		/// <summary>
		/// Allows the game component to perform any initialization it needs to before starting
		/// to run.  This is where it can query for any required services and load content.
		/// </summary>
		public override void Initialize()
		{
			base.Initialize();
		}


		/// <summary>
		/// Allows the game component to update itself.
		/// </summary>
		/// <param name="gameTime">Provides a snapshot of timing values.</param>
		public override void Update(GameTime gameTime)
		{
			ICamera camera = CameraManager.ActiveCamera;


			drawOrder.Clear();
			foreach (var model in models)
			{
				for (int i = 0; i < model.Value.Instances.Length; i++)
				{
					if (model.Value.Instances[i].Bounds.Intersects(camera.Frustum))
					{
						drawOrder.Add(new DrawOrder(eModelType.Simple, model.Key, i, model.Value.Instances[i].World.Translation));
					}
				}
			}

			foreach (var model in instancedModels)
			{
				for (int i = 0; i < model.Value.Instances.Length; i++)
				{
					if (model.Value.Instances[i].Bounds.Intersects(camera.Frustum))
					{
						//if any one model is included they all are...
						drawOrder.Add(new DrawOrder(eModelType.Instanced, model.Key, i, model.Value.Instances[i].World.Translation));
						break;
					}
				}
			}
			foreach (var model in cubes)
			{

				if (model.Value.Info.Bounds.Intersects(camera.Frustum))
				{
					//if any one model is included they all are...
					drawOrder.Add(new DrawOrder(eModelType.Cube, model.Key, null, model.Value.Info.World.Translation));
					
				}

			}

			foreach (var model in normalSpecDiffuseModels)
			{
				for (int i = 0; i < model.Value.Instances.Length; i++)
				{
					if (model.Value.Instances[i].Bounds.Intersects(camera.Frustum))
					{
						drawOrder.Add(new DrawOrder(eModelType.NormalSpecDiffuseModel, model.Key, i, model.Value.Instances[i].World.Translation));
					}
				}
			}
			RadialSort(camera.Position);

			base.Update(gameTime);
		}


		private void RadialSort(Vector3 origin)
		{
			float[] dist = new float[2];
			bool ordered = false;
			DrawOrder hold;
			while (!ordered)
			{
				ordered = true;
				for (int a = 0; a < this.drawOrder.Count; a++)
				{
					dist[0] = Vector3.Distance(origin, drawOrder[a].Position);
					for (int b = drawOrder.Count - 1; b > a; b--)
					{
						dist[1] = Vector3.Distance(origin, drawOrder[b].Position);
						if (dist[0] > dist[1])
						{
							hold = drawOrder[a];
							drawOrder.RemoveAt(a);
							drawOrder.Insert(b, hold);
							ordered = false;
						}
					}
				}
			}
		}
		public override void Draw(GameTime gameTime)
		{
			foreach (var item in drawOrder)
			{
				switch (item.Type)
				{
					case eModelType.Simple:
						models[item.Key].Draw(CameraManager.ActiveCamera.View, CameraManager.ActiveCamera.Projection, item.Index.Value);
						break;
					case eModelType.Instanced:
						instancedModels[item.Key].Draw(CameraManager.ActiveCamera.View, CameraManager.ActiveCamera.Projection);
						break;
					case eModelType.Cube:
						cubes[item.Key].Draw(CameraManager.ActiveCamera.View, CameraManager.ActiveCamera.Projection);
						break;
					case eModelType.NormalSpecDiffuseModel:
						normalSpecDiffuseModels[item.Key].Draw(CameraManager.ActiveCamera.View, CameraManager.ActiveCamera.Projection, item.Index.Value);
						break;
					default:
						break;
				}
			}

#if DEBUG
			SharedResources.SpriteBatch.Begin();
			SharedResources.SpriteBatch.DrawString(SharedResources.DebugFont, String.Format("Drawing {0} models", drawOrder.Count.ToString()), new Vector2(200, 200), Color.Teal);
			SharedResources.SpriteBatch.End();
#endif
			base.Draw(gameTime);
		}

		protected override void LoadContent()
		{
			//Handel Child object content loading
			Cubes.LoadContent();
			

			base.LoadContent();
		}
		public static List<BoundingBox> GetBoundingBoxes(eModelType type)
		{
			List<BoundingBox> retval = new List<BoundingBox>();
			switch (type)
			{
				case eModelType.Simple:
					foreach (var m in models) { foreach (var item in m.Value.Instances) { retval.Add(item.Bounds); } }
					break;
				case eModelType.Instanced:
					foreach (var m in instancedModels) { foreach (var item in m.Value.Instances) { retval.Add(item.Bounds); } }
					break;
				case eModelType.Cube:
					foreach (var m in cubes) { retval.Add(m.Value.Info.Bounds); }
					break;
				case eModelType.NormalSpecDiffuseModel:
					foreach (var m in normalSpecDiffuseModels) { foreach (var item in m.Value.Instances) { retval.Add(item.Bounds); } }
					break;
				default:
					break;
			}
			return retval;
		}
	}
}

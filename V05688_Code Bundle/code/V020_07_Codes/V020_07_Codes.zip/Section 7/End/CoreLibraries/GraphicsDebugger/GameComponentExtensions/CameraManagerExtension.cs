﻿using System.Linq;
using Camera;
using GameComponents;
using Microsoft.ShapeRenderingSample;

namespace GraphicsDebugger.GameComponentExtensions
{
	public static class CameraManagerExtension
	{
#if DEBUG
		public static void DrawCameras(this CameraManager @this)
		{
			for (int i = 0; i < CameraManager.Cameras.Count; i++)
			{
				//push the new frustrums to the DebugDrawer
				// send in 0.0001f for lifetime to get one frame
				DebugShapeRenderer.AddBoundingFrustum(CameraManager.Cameras.ElementAt(i).Value.Frustum, CameraManager.GetColor((eCameraType)i), 0.0001f);
			}
		}
#endif
	}
}

﻿using System.Collections.Generic;
using System.Linq;
using Core.IO;

namespace Core.HLSL
{
	public static class ShaderLibrary
	{
		private static  Dictionary<string, IShader> shaders = new Dictionary<string, IShader>();
		public static void Load(string path) 
		{
			Load(path, path.GetFileFromPath());
		}
		public static void Load(string path, string key)
		{
			shaders.Add(key, new Shader(path));
		}
		public static void Remove(string key) { shaders.Remove(key); }
		public static Dictionary<string, IShader> Shaders { get { return shaders; } set { shaders = value; } }
	}

}

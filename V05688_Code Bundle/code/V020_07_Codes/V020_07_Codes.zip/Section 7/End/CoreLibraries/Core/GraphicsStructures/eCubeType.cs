﻿
namespace Core.GraphicsStructures
{
	public enum eCubeType
	{
		Default,
		Metal,
		Psychadelic,
	}
}

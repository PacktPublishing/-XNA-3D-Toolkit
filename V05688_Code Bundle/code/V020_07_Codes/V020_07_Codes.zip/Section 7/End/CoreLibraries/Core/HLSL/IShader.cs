﻿using Microsoft.Xna.Framework.Graphics;

namespace Core.HLSL
{
	public interface IShader
	{
		Effect Effect { get; set; }
	}

}

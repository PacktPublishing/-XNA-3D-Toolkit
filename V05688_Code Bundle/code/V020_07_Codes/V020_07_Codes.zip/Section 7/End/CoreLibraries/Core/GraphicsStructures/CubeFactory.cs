﻿using Core.Helpers;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace Core.GraphicsStructures
{
	public static class Cubes
	{

		public static Texture2D[] textures;

		public static Cube DefaultCube(Vector3 position)
		{
			return Make(position, eCubeType.Default);
		}

		public static Cube Metalic(Vector3 position)
		{
			return Make(position, eCubeType.Metal);
		}
		public static Cube Psychadelic(Vector3 position)
		{
			return Make(position, eCubeType.Psychadelic);
		}

		public static Cube Make( Vector3 position, eCubeType type)
		{
			return new Cube(position, textures[(byte)type]);
		}

		public static void LoadContent()
		{
			textures = new Texture2D[]{
				SharedResources.ContentManager.Load<Texture2D>("GraphicsSupportItems/GreenPixel"),
				SharedResources.ContentManager.Load<Texture2D>("GraphicsSupportItems/Metal"),
				SharedResources.ContentManager.Load<Texture2D>("GraphicsSupportItems/PixelGrid")
				};
		}

		public static Cube Make(Vector3 position, string assetPath)
		{
			var temp =new Texture2D[textures.Length+1];
			textures.CopyTo(temp, 0);
			temp[textures.Length] = SharedResources.ContentManager.Load<Texture2D>(assetPath);
			textures = temp;
			return new Cube(position, textures[textures.Length-1]);
		}
	}
}

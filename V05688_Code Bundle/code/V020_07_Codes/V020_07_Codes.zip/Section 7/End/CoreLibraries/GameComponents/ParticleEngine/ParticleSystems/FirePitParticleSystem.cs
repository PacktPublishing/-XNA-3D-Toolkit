﻿
using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Particle3DSample;
using Core;

namespace GameComponents.ParticleEngine.ParticleSystems
{
	public class FirePitParticleSystem : ParticleSystem, INoun
	{
		private float radius;

		public float Radius
		{
			get { return radius; }
			set { radius = value; }
		}
		Noun me = new Noun();
		public FirePitParticleSystem(Vector3 pos, float radius) 
		{
			this.me.Position = pos;
			this.radius = radius;
		}
		private float scale = 1;
		private byte[] smokieness = new byte[]{0,3};

		public byte[] Smokieness
		{
			get { return smokieness; }
			set { smokieness = value; }
		}

		protected override void InitializeSettings(ParticleSettings settings)
		{
			settings.TextureName = "fire";

			settings.MaxParticles = 2400;

			settings.Duration = TimeSpan.FromSeconds(2);

			settings.DurationRandomness = 1;

			settings.MinHorizontalVelocity = 0.000005f;
			settings.MaxHorizontalVelocity = 0.00001F;

			settings.MinVerticalVelocity = -1f * scale;
			settings.MaxVerticalVelocity = 1 * scale;

			// Set gravity upside down, so the flames will 'fall' upward.
			settings.Gravity = new Vector3(0, 5 * scale, 0);

			settings.MinColor = new Color(255, 255, 255, 10);
			settings.MaxColor = new Color(255, 255, 255, 40);

			settings.MinStartSize = 1;
			settings.MaxStartSize = 5;

			settings.MinEndSize = 0.01F;
			settings.MaxEndSize = 7;

			// Use additive blending.
			settings.BlendState = BlendState.Additive;
		}

		public Matrix Transform
		{
			get
			{
				return me.Transform;
			}
			set
			{
				me.Transform = value;
			}
		}

		public Quaternion Rotation
		{
			get
			{
				return this.me.Rotation;
			}
			set
			{
				this.Rotation = value;
			}
		}

		public Vector3 Position { get { return this.me.Position; } set { this.me.Position = value; } }

		public Vector3 Up
		{
			get { return me.Up; }
		}

		public Vector3 Forward
		{
			get { return me.Forward; }
		}

		public Vector3 Right
		{
			get { return me.Right; }
		}

		internal bool DrawSmokethisFrame()
		{
			if (this.smokieness[0] == this.smokieness[1])
			{
				this.smokieness[0] = 0;
				return true;
			}
			else
			{
				this.smokieness[0] += 1;
				return false;
			}
		}
	}
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Core;
using Physics.SystemDefinitions;
using Microsoft.Xna.Framework;
using Core.Helpers;

namespace GameComponents.Lighting
{
	public class FlickeringFire: INoun, ILight, ITwoBodySystem, IUpdate
	{


		private float radius;
		INoun token = new Noun();
		INoun fireSource = new Noun();

		float lightIntensity;

		public FlickeringFire(float radius, INoun lightEmmitingObject)
		{

			this.radius = radius;
			this.ImmobileBody = lightEmmitingObject;
			this.MobileBody.Transform = this.ImmobileBody.Transform;

		}
		public float Radius
		{
			get { return radius; }
			set { radius = value; }
		}
		public Vector3 LightSourcePosition
		{
			get
			{
				return this.token.Position;
			}
		}

		public float LightIntensity
		{
			get { return this.lightIntensity; }
			set { this.lightIntensity = value; }
		}

		#region Not implemented
		public Color LightColor
		{
			get
			{
				throw new NotImplementedException();
			}
			set
			{
				throw new NotImplementedException();
			}
		}

		public Color AmbientLightColor
		{
			get
			{
				throw new NotImplementedException();
			}
			set
			{
				throw new NotImplementedException();
			}
		}

		public Matrix Transform
		{
			get
			{
				throw new NotImplementedException();
			}
			set
			{
				throw new NotImplementedException();
			}
		}

		public Quaternion Rotation
		{
			get
			{
				throw new NotImplementedException();
			}
			set
			{
				throw new NotImplementedException();
			}
		}
		#endregion
		public Vector3 Position
		{
			get
			{
				return this.token.Position;
			}
			set
			{
				this.token.Position = value;
			}
		}

		public Vector3 Up
		{
			get { return Vector3.Up; }
		}

		public Vector3 Forward
		{
			get { return Vector3.UnitX; }
		}

		public Vector3 Right
		{
			get { return Vector3.UnitZ; }
		}

		public INoun ImmobileBody
		{
			get
			{
				return this.fireSource;
			}
			set
			{
				this.fireSource = value;
			}
		}

		public INoun MobileBody
		{
			get
			{
				return this.token;
			}
			set
			{
				this.token = value;
			}
		}


		public void Update()
		{
			//Once a cycle we want to change
			//where our light is this would also be a good place change how intense it is, and what color it is giving off.

			//move the "fire tip"
			var flickerVelocity = new Vector3(
				(float)SharedResources.R.NextDouble(),
				(float)SharedResources.R.NextDouble(),
			(float)SharedResources.R.NextDouble());
			//var tempPosition = Vector3.Lerp(token.Position, fireSource.Position + flickerVelocity, 0.5f);
			//Keep the light source close to the origin
			token.Position = Vector3.Lerp(token.Position, fireSource.Position + flickerVelocity, 0.5f);//fireSource.Position + flickerVelocity;
		}
	}
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Camera;

namespace GameComponents
{
	public class SceneDefinition
	{
		public class NDModelAssetInfo 
		{
			public string Name, AssetPath, NormalPath, ColorPath;
			public List<Matrix> Instances;
			public int? DrawOrderSuggestion;
			public NDModelAssetInfo()
			{ }
			public NDModelAssetInfo(string assetName, string assetPath, string normalPath, string diffusePath, Matrix[] locations, int? drawOrderSuggestion) 
			{
				this.Name = assetName;
				this.AssetPath = assetPath;
				this.NormalPath = normalPath;
				this.ColorPath = diffusePath;
				this.Instances = new List<Matrix>();
				this.Instances.AddRange(locations);
				this.DrawOrderSuggestion = drawOrderSuggestion;
			}
		}
		public class CameraAssetInfo
		{
			public eCameraType Type; 
			
			
			///<Summary> For casting information see class definition
			///</Summary>
			public object Info;
			public CameraAssetInfo()
			{ }
			public CameraAssetInfo(eCameraType type, object info)
			{
				this.Type = type;
				this.Info = info;
			}
		}
		public class ParticleAssetInfo 
		{
			public Vector3 CampFirePosition;
			public float CampFireRadius;
			/// <summary>
			/// If it has a value then it is a light emmitter
			/// </summary>
			public float? LightRadius;
		}
		public class PlayerAssetInfo 
		{ 
			public Vector3 Position; 
		}
		public class GameAssetInfo 
		{ 
			public Color BackgroundColor;
		}

		public List<CameraAssetInfo> Cameras = new List<CameraAssetInfo>();
		public GameAssetInfo Game = new GameAssetInfo();
		public List<NDModelAssetInfo> NDModels = new List<NDModelAssetInfo>();
		public ParticleAssetInfo Particles = new ParticleAssetInfo();
		public PlayerAssetInfo Player = new PlayerAssetInfo();

		
	}
	public class SceneDefinitionException : Exception
	{

		public SceneDefinitionException() : base() { }

		public SceneDefinitionException(string message) :
			base(string.Format("Definition Construction Errors:{0}", message)) { }

		public SceneDefinitionException(string p, Exception e):
			base(string.Format("Definition Construction Errors{0}:", p), e)
		{
		}
	}
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Particle3DSample;
using Microsoft.Xna.Framework;
using Core.Helpers;
using Core;
using Microsoft.Xna.Framework.Input;
using GameComponents.ParticleEngine.ParticleSystems;

namespace GameComponents.ParticleEngine
{
	public class ParticleMaster : DrawableGameComponent, IHandlesInput
	{

		// This sample uses five different particle systems.
		ParticleSystem explosionParticles;
		ParticleSystem explosionSmokeParticles;
		ParticleSystem projectileTrailParticles;
		ParticleSystem smokePlumeParticles;
		ParticleSystem fireParticles;
		public FirePitParticleSystem pitParticles;

		// The sample can switch between three different visual effects.
		enum ParticleState
		{
			Explosions,
			SmokePlume,
			RingOfFire,
			FirePit,
		};

		ParticleState currentState = ParticleState.FirePit;





		// The explosions effect works by firing projectiles up into the
		// air, so we need to keep track of all the active projectiles.
		List<Projectile> projectiles = new List<Projectile>();

		TimeSpan timeToNextProjectile = TimeSpan.Zero;
		public ParticleMaster() : base(SharedResources.Game) { }
		public override void Update(GameTime gameTime)
		{
			HandleInput();

			switch (currentState)
			{
				case ParticleState.Explosions:
					UpdateExplosions(gameTime);
					break;

				case ParticleState.SmokePlume:
					UpdateSmokePlume();
					break;

				case ParticleState.RingOfFire:
					UpdateFire();
					break;

				case ParticleState.FirePit:
					UpdateFirePit();
					break;
			}

			UpdateProjectiles(gameTime);

			base.Update(gameTime);
		}

		protected override void LoadContent()
		{// Construct our particle system components.
			explosionParticles = new ExplosionParticleSystem();
			explosionSmokeParticles = new ExplosionSmokeParticleSystem();
			projectileTrailParticles = new ProjectileTrailParticleSystem();
			smokePlumeParticles = new SmokePlumeParticleSystem();
			fireParticles = new FireParticleSystem();
			pitParticles = new FirePitParticleSystem(Vector3.Zero, 0.5f);
			// Set the draw order so the explosions and fire
			// will appear over the top of the smoke.
			smokePlumeParticles.DrawOrder = 100;
			explosionSmokeParticles.DrawOrder = 200;
			projectileTrailParticles.DrawOrder = 300;
			explosionParticles.DrawOrder = 400;
			fireParticles.DrawOrder = 500;
			pitParticles.DrawOrder = 550; ;

			// Register the particle system components.
			SharedResources.Game.Components.Add(explosionParticles);
			SharedResources.Game.Components.Add(explosionSmokeParticles);
			SharedResources.Game.Components.Add(projectileTrailParticles);
			SharedResources.Game.Components.Add(smokePlumeParticles);
			SharedResources.Game.Components.Add(fireParticles);
			SharedResources.Game.Components.Add(pitParticles);
			base.LoadContent();
		}
		
        /// <summary>
        /// Helper for updating the explosions effect.
        /// </summary>
        void UpdateExplosions(GameTime gameTime)
        {
            timeToNextProjectile -= gameTime.ElapsedGameTime;

            if (timeToNextProjectile <= TimeSpan.Zero)
            {
                // Create a new projectile once per second. The real work of moving
                // and creating particles is handled inside the Projectile class.
                projectiles.Add(new Projectile(explosionParticles,
                                               explosionSmokeParticles,
                                               projectileTrailParticles));

                timeToNextProjectile += TimeSpan.FromSeconds(1);
            }
        }


        /// <summary>
        /// Helper for updating the list of active projectiles.
        /// </summary>
        void UpdateProjectiles(GameTime gameTime)
        {
            int i = 0;

            while (i < projectiles.Count)
            {
                if (!projectiles[i].Update(gameTime))
                {
                    // Remove projectiles at the end of their life.
                    projectiles.RemoveAt(i);
                }
                else
                {
                    // Advance to the next projectile.
                    i++;
                }
            }
        }


        /// <summary>
        /// Helper for updating the smoke plume effect.
        /// </summary>
        void UpdateSmokePlume()
        {
            // This is trivial: we just create one new smoke particle per frame.
            smokePlumeParticles.AddParticle(Vector3.Zero, Vector3.Zero);
        }


        /// <summary>
        /// Helper for updating the fire effect.
        /// </summary>
        void UpdateFire()
        {
            const int fireParticlesPerFrame = 20;

            // Create a number of fire particles, randomly positioned around a circle.
            for (int i = 0; i < fireParticlesPerFrame; i++)
            {
                fireParticles.AddParticle(RandomPointOnCircle(), Vector3.Zero);
            }

            // Create one smoke particle per frmae, too.
            smokePlumeParticles.AddParticle(RandomPointOnCircle(), Vector3.Zero);
        }


		private void UpdateFirePit()
		{
			const int fireParticlesPerFrame = 20;

			// Create a number of fire particles, randomly positioned inside a circle.
			for (int i = 0; i < fireParticlesPerFrame; i++)
			{
				var tempPosition = RandomPointInCircle(pitParticles.Position, pitParticles.Radius/3);
				//if (Vector3.Distance(tempPosition, pitParticles.Position)>pitParticles.Radius) throw new SystemException();
				pitParticles.AddParticle(tempPosition, Vector3.Zero);
			}

			// Create one smoke particle per frmae, too.
			if (pitParticles.DrawSmokethisFrame())
			{
				smokePlumeParticles.AddParticle(RandomPointInCircle(
					pitParticles.Position + new Vector3(0, 0.01f, 0),//keep the smoke inside the fire
					pitParticles.Radius * .025f), Vector3.Zero);
			}
		}

		private Vector3 RandomPointInCircle(Vector3 vCenter, float radius)
		{
			var epsilon = .000025f;
			// get a random angle [0 , 2-Pi]
			var angle = SharedResources.R.NextDouble() * Math.PI;
			// get a random radius inside the circle
			var rad = SharedResources.R.NextDouble()*radius;
			//Make sure we don't get a divide by 0 exception
			rad += (rad<epsilon?epsilon:0);
			// fire pits are always in the XZ plane
			var localPosition = new Vector3((float)(Math.Cos(angle) * rad), 0, (float)(Math.Sin(angle) * rad));
			return vCenter+localPosition;

		}
        /// <summary>
        /// Helper used by the UpdateFire method. Chooses a random location
        /// around a circle, at which a fire particle will be created.
        /// </summary>
        Vector3 RandomPointOnCircle()
        {
            const float radius = 30;
            const float height = 40;

            double angle = SharedResources.R.NextDouble() * Math.PI * 2;

            float x = (float)Math.Cos(angle);
            float y = (float)Math.Sin(angle);

            return new Vector3(x * radius, y * radius + height, 0);
        }


        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        public override void Draw(GameTime gameTime)
        {

            var view = CameraManager.ActiveCamera.View;
			var projection = CameraManager.ActiveCamera.Projection;
            // Pass camera matrices through to the particle system components.
            explosionParticles.SetCamera(view, projection);
            explosionSmokeParticles.SetCamera(view, projection);
            projectileTrailParticles.SetCamera(view, projection);
            smokePlumeParticles.SetCamera(view, projection);
            fireParticles.SetCamera(view, projection);
			pitParticles.SetCamera(view, projection);

#if DEBUG
            DrawMessage();
#endif
            // This will draw the particle system components.
            base.Draw(gameTime);
        }


        /// <summary>
        /// Helper for drawing our message text.
        /// </summary>
        void DrawMessage()
        {
			//string message = string.Format("Current effect: {0}!!!\n" +
			//                               "Hit the A button or space bar to switch.",
			//                               currentState);

			//SharedResources.SpriteBatch.Begin();
			//SharedResources.SpriteBatch.DrawString(SharedResources.DebugFont, message, new Vector2(50, 50), Color.White);
			//SharedResources.SpriteBatch.End();
        }



        /// <summary>
        /// Handles input for quitting the game and cycling
        /// through the different particle effects.
        /// </summary>
       public void HandleInput()
        {
            

            // Check for changing the active particle effect.
            if ( SharedResources.KeyboardPressedAndReleased(Keys.Space))
            {
                currentState++;

                if (currentState > ParticleState.FirePit)
                    currentState = 0;
            }
        }
	}
}

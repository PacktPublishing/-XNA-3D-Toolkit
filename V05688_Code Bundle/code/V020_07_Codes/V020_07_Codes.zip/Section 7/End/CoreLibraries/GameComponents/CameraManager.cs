﻿using System.Collections.Generic;
using System.Linq;
using Camera;
using Core.Helpers;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using System;

namespace GameComponents
{

	/// <summary>
	/// This is a game component that implements IUpdateable.
	/// </summary>
	public class CameraManager : DrawableGameComponent
	{
		private static eCameraType currentCamera = eCameraType.FirstPerson;
		private static Dictionary<eCameraType, ICamera> cameras = new Dictionary<eCameraType, ICamera>();
#if DEBUG
		public static Dictionary<eCameraType, ICamera> Cameras { get { return cameras; } }
#endif
		


		public CameraManager()
			: base(SharedResources.Game)
		{
			// TODO: Construct any child components here

		}

		/// <summary>
		/// Allows the game component to perform any initialization it needs to before starting
		/// to run.  This is where it can query for any required services and load content.
		/// </summary>
		public override void Initialize()
		{
			base.Initialize();
		}


		/// <summary>
		/// Allows the game component to update itself.
		/// </summary>
		/// <param name="gameTime">Provides a snapshot of timing values.</param>
		public override void Update(GameTime gameTime)
		{
			ActiveCamera.Update();

			// Toggle the state of the camera.
			if (SharedResources.KeyboardPressedAndReleased(Keys.Tab) ||
				(SharedResources.CurrentGamePadState.Buttons.LeftShoulder == ButtonState.Pressed))
			{
				if ((byte)currentCamera + 1 >= System.Enum.GetNames(typeof(eCameraType)).Count())
				{ currentCamera = (eCameraType)0; }
				else { currentCamera = (eCameraType)((byte)currentCamera + 1); }
			}

			base.Update(gameTime);
		}

#if DEBUG
		public static Color GetColor(eCameraType type)
		{

			switch (type)
			{
				//case eCameraType.Orthographic:
				//    return Color.Gold;
				//case eCameraType.Chase:
				//    return Color.Red;
				case eCameraType.FirstPerson:
					return Color.Salmon;
				case eCameraType.ThirdPerson:
					return Color.Tomato;
				//case eCameraType.Rotating:
				//    return Color.Thistle;
				default:
					throw new ArgumentOutOfRangeException(String.Format("{0} is not a valid type", type.ToString()));
			}
			return Color.Black;
		}
#endif

		public override void Draw(GameTime gameTime)
		{
			var sb = SharedResources.SpriteBatch;
			sb.Begin();

			switch (currentCamera)
			{
				//case eCameraType.Rotating:
				//    sb.DrawString(SharedResources.DebugFont, eCameraType.Rotating.ToString(), new Vector2(10, 80), Color.Thistle);
				//    sb.DrawString(SharedResources.DebugFont, eCameraType.Orthographic.ToString(), new Vector2(10, 120), Color.Gold);
				//    sb.DrawString(SharedResources.DebugFont, eCameraType.Chase.ToString(), new Vector2(10, 150), Color.Red);
				//    sb.DrawString(SharedResources.DebugFont, eCameraType.FirstPerson.ToString(), new Vector2(10, 180), Color.Salmon);
				//    sb.DrawString(SharedResources.DebugFont, eCameraType.ThirdPerson.ToString(), new Vector2(10, 210), Color.Tomato);
				//    break;
				case eCameraType.FirstPerson:
				
					break;
				default:
					break;
			}
			sb.End();

			base.Draw(gameTime);
		}


		public static ICamera ActiveCamera
		{
			get
			{
				return cameras[currentCamera];
			}
		}

		public void Add(ICamera cam)
		{
			cameras.Add(cam.Type, cam);
		}
	}


}

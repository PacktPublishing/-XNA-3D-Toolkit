﻿//using Core;
//using Core.Helpers;
//using Microsoft.Xna.Framework;
//using Microsoft.Xna.Framework.Input;

//namespace Camera.Stategies
//{

//    public class OrthographicCamera : CameraBase, ICamera, IHandlesInput
//    {
//        public OrthographicCamera(INoun target, Vector3 position)
//            : base(target, position, eCameraType.Orthographic)
//        {
//        }
//        void ICamera.Update()
//        {
//            projection = Matrix.CreateOrthographic(10, 10, -10f, 20f);
//            HandleInput();
//            view = Matrix.CreateLookAt(Position, target.Position, Vector3.Up);
//            base.Update();
//        }

//        public void HandleInput()
//        {
//            if (SharedResources.KeyboardPressedAndReleased(Keys.A))
//            {
//                this.Position += new Vector3(0.5f, 0, 0);
//            }
//            if (SharedResources.KeyboardPressedAndReleased(Keys.S))
//            {
//                this.Position += new Vector3(-0.5f, 0, 0);
//            }
//            if (SharedResources.KeyboardPressedAndReleased(Keys.W))
//            {
//                this.Position += new Vector3(0, 0.5f, 0);
//            }
//            if (SharedResources.KeyboardPressedAndReleased(Keys.Z))
//            {
//                this.Position += new Vector3(0, -0.5f, 0);
//            }
//            if (SharedResources.KeyboardPressedAndReleased(Keys.Q))
//            {
//                this.Position += new Vector3(0, 0, 0.5f);
//            }
//            if (SharedResources.KeyboardPressedAndReleased(Keys.E))
//            {
//                this.Position += new Vector3(0, 0, -0.5f);
//            }
//        }

//    }

//}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
		using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Core;
using Physics;
using Core.Helpers;

namespace Camera.Stategies
{
	public class ThirdPersonCamera : CameraBase, IHandlesInput, ICamera
	{
		private Vector3 lookFromOffset;
		
		public ThirdPersonCamera(INoun target, float dist)
			: base(target, Vector3.Zero, eCameraType.ThirdPerson)
		{
			lookFromOffset = new Vector3(0, dist, -dist);
		}

		public void HandleInput()
		{
			//The motion of this camera is controlled in Update;
		}

		public new void Update()
		{

			view = Matrix.CreateLookAt(target.Position + lookFromOffset, target.Position, Vector3.Up);
			projection = Matrix.CreatePerspectiveFieldOfView(
				MathHelper.PiOver4, SharedResources.GraphicsDevice.Viewport.AspectRatio, .1f, 1000f);
			base.Update();
		}
	}
}

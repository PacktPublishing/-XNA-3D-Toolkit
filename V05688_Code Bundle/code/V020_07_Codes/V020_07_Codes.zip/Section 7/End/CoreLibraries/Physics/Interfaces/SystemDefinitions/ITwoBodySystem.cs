﻿using Core;

namespace Physics.SystemDefinitions
{
	public interface ITwoBodySystem
	{
		INoun ImmobileBody { get; set; }
		INoun MobileBody { get; set; }
	}
}

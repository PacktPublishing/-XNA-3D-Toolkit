using System;
using Core.Helpers;
using Core.Helpers.Interfaces;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System.Collections.Generic;
using GameComponents;
#if DEBUG
using System.Linq;
using Microsoft.ShapeRenderingSample;
using Microsoft.CollisionSample;
using Microsoft.VertexLightingSample;
using GraphicsDebugger;
using Camera;
using GraphicsDebugger.GameComponentExtensions;
using Core.Tokens;
using Camera.Stategies;
using Core.Collections;
using GameComponents.Enumerations;
using Core.HLSL;
using GameComponents.ParticleEngine;
using GameComponents.Lighting;
using System.IO;
using System.Xml.Serialization;
using System.Xml;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content.Pipeline.Serialization.Intermediate;
#endif

namespace StarterGame
{
	/// <summary>
	/// This is the main type for your game
	/// </summary>
	public class StarterGame : Game, IGame
	{

#if DEBUG
		private SampleGrid grid;
#endif
		CameraManager cameraManager;
		PlayerComponent player;
		SceneDefinition definition = new SceneDefinition();

		ParticleMaster particles;

		public StarterGame()
		{
			SharedResources.OnCreate(this);
			particles = new ParticleMaster();
			cameraManager = new CameraManager();
			player = new PlayerComponent(new SnowmanToken());
			this.Components.Add(cameraManager);
			this.Components.Add(player);
			this.Components.Add(new DrawOrderManager());
			this.Components.Add(particles);
#if DEBUG
			this.Components.Add(new FrameRateCounter(this));
#endif
			Content.RootDirectory = "GameContent(HiDef)";
		}

		/// <summary>
		/// Allows the game to perform any initialization it needs to before starting to run.
		/// This is where it can query for any required services and load any non-graphic
		/// related content.  Calling base.Initialize will enumerate through any components
		/// and initialize them as well.
		/// </summary>
		protected override void Initialize()
		{
#if DEBUG
			DebugShapeRenderer.Initialize(this.GraphicsDevice);
#endif

			SharedResources.OnInitialize(this);
			// TODO: Add your initialization logic here



			base.Initialize();
		}

		/// <summary>
		/// LoadContent will be called once per game and is the place to load
		/// all of your content.
		/// </summary>
		protected override void LoadContent()
		{
			SharedResources.OnLoadContent(this);

			this.definition = Content.Load<SceneDefinition>("Scene");

			SharedResources.BackgroundColor = definition.Game.BackgroundColor;

			player.Player.Position = definition.Player.Position;

			foreach (var item in definition.Cameras)
			{
				try
				{
					switch (item.Type)
					{
						case eCameraType.FirstPerson:
							Vector3? vec = (item.Info as Vector3?);
							cameraManager.Add(new FirstPersonCamera(player.Player, vec.Value));
							break;
						case eCameraType.ThirdPerson:
							float? dist = (item.Info as float?);
							cameraManager.Add(new ThirdPersonCamera(player.Player, dist.Value));
							break;
						default:
							throw new SceneDefinitionException(String.Format("Camera type Undefined:{0}", item.Type));
					}
				}
				catch (SceneDefinitionException e)
				{
					throw e;
				}
				catch (Exception e)
				{
					throw new SceneDefinitionException(String.Format("Probably casting value wrong:{0}", item.Type), e);
				}
			}

			particles.pitParticles.Position = definition.Particles.CampFirePosition;
			particles.pitParticles.Radius = definition.Particles.CampFireRadius;
			if (definition.Particles.LightRadius.HasValue)
			{
				LightingManager.LightSources.Add(new FlickeringFire(definition.Particles.LightRadius.Value, particles.pitParticles));
			}
			foreach (var item in definition.NDModels)
			{

				DrawOrderManager.AddNormalDiffuseModel(item.Name, item.AssetPath, item.NormalPath, item.ColorPath, item.Instances.ToArray(), item.DrawOrderSuggestion);
			}

#if DEBUG

			//Set up the reference grid
			grid = new SampleGrid();
			grid.GridColor = Color.LimeGreen;
			grid.GridScale = 1.0f;
			grid.GridSize = 32;
			grid.LoadGraphicsContent();
			//Set the grid to draw on the x/z plane around the origin
			grid.WorldMatrix = Matrix.Identity;
#endif

		}
		public void Save(string filename)
		{
			XmlWriterSettings settings = new XmlWriterSettings();
			settings.Indent = true;

			using (XmlWriter writer = XmlWriter.Create(filename, settings))
			{
				IntermediateSerializer.Serialize(writer, this.definition, null);
			}
		}

		/// <summary>
		/// UnloadContent will be called once per game and is the place to unload
		/// all content.
		/// </summary>
		protected override void UnloadContent()
		{

			SharedResources.OnUnLoadContent(this);
			// TODO: Unload any non ContentManager content here
		}

		/// <summary>
		/// Allows the game to run logic such as updating the world,
		/// checking for collisions, gathering input, and playing audio.
		/// </summary>
		/// <param name="gameTime">Provides a snapshot of timing values.</param>
		protected override void Update(GameTime gameTime)
		{
			SharedResources.OnBeginUpdate(gameTime);

			SharedResources.OnUpdate(this);
			LightingManager.Update();
			if (SharedResources.KeyboardPressedAndReleased(Keys.S))
			{ Save("Scene.xml"); }

			base.Update(gameTime);
			SharedResources.OnEndUpdate();
		}

		/// <summary>
		/// This is called when the game should draw itself.
		/// </summary>
		/// <param name="gameTime">Provides a snapshot of timing values.</param>
		protected override void Draw(GameTime gameTime)
		{
			SharedResources.Draw(this);
			//the SpriteBatch added below to draw the current technique name
			//is changing some needed render states, so they are reset here.
			this.GraphicsDevice.DepthStencilState = DepthStencilState.Default;
			//draw the reference grid so it's easier to get our bearings

			// TODO: Add your drawing code here

			var bounding = DrawOrderManager.GetBoundingBoxes(eModelType.Cube);
			foreach (var box in bounding)
			{
				DebugShapeRenderer.AddBoundingBox(box, Color.Violet);
			}

			bounding = DrawOrderManager.GetBoundingBoxes(eModelType.Instanced);
			foreach (var box in bounding)
			{
				DebugShapeRenderer.AddBoundingBox(box, Color.Black);
			}

			bounding = DrawOrderManager.GetBoundingBoxes(eModelType.Simple);
			foreach (var box in bounding)
			{
				DebugShapeRenderer.AddBoundingBox(box, Color.DarkOliveGreen);
			}


			base.Draw(gameTime);




			SharedResources.SpriteBatch.Begin();

#if DEBUG
			SharedResources.SpriteBatch.DrawString(SharedResources.DebugFont, "Light Position" + LightingManager.LightSources[0].LightSourcePosition.ToString(), new Vector2(50, 120), Color.WhiteSmoke);
			SharedResources.SpriteBatch.DrawString(SharedResources.DebugFont, "Player Position" + player.Player.Position.ToString(), new Vector2(50, 100), Color.WhiteSmoke);
			//SharedResources.SpriteBatch.DrawString(SharedResources.DebugFont, "Debug", new Vector2(50, 50), Color.Black);
#else
			//SharedResources.SpriteBatch.DrawString(SharedResources.DebugFont, "Release", new Vector2(50,50), Color.Black);
#endif
			SharedResources.SpriteBatch.End();
		}

		public Game xnaGame
		{
			get
			{
				return this;
			}
			set
			{
				throw new NotImplementedException();
			}
		}

		public void CreateAssets()
		{
		}
	}
}

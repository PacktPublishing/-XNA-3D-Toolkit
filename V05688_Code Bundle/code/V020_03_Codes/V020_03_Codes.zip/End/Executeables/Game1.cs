using System;
using Core.Helpers;
using Core.Helpers.Interfaces;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System.Collections.Generic;
using GameComponents;
using Camera.Strategies;
#if DEBUG
using Microsoft.ShapeRenderingSample;
using Microsoft.CollisionSample;
using Microsoft.VertexLightingSample;
using GraphicsDebugger;
#endif

namespace StarterGame
{
	/// <summary>
	/// This is the main type for your game
	/// </summary>
	public class StarterGame : Game, IGame
	{
		
#if DEBUG
		private SampleGrid grid;
#endif
		CameraManager cameraManager;
		PlayerComponent player;
		Dictionary<string, Model> Models = new Dictionary<string, Model>();


		public StarterGame()
		{

			SharedResources.OnCreate(this);
			cameraManager = new CameraManager();
			player = new PlayerComponent();
			this.Components.Add(cameraManager);
			this.Components.Add(player);
#if DEBUG
			this.Components.Add(new FrameRateCounter(this));
#endif
			Content.RootDirectory = "GameContent(HiDef)";
		}

		/// <summary>
		/// Allows the game to perform any initialization it needs to before starting to run.
		/// This is where it can query for any required services and load any non-graphic
		/// related content.  Calling base.Initialize will enumerate through any components
		/// and initialize them as well.
		/// </summary>
		protected override void Initialize()
		{
#if DEBUG
			DebugShapeRenderer.Initialize(this.GraphicsDevice);
#endif

			SharedResources.OnInitialize(this);
			// TODO: Add your initialization logic here
			


			base.Initialize();
		}

		/// <summary>
		/// LoadContent will be called once per game and is the place to load
		/// all of your content.
		/// </summary>
		protected override void LoadContent()
		{
			SharedResources.OnLoadContent(this);

			cameraManager.Add(new RotatingCamera());

			// TODO: use this.Content to load your game content here
			Models.Add("Cone", Content.Load<Model>("Cone"));
			Models.Add("Cube", Content.Load<Model>("Cube"));
			Models.Add("Cylinder", Content.Load<Model>("Cylinder"));
			Models.Add("SphereHighPoly", Content.Load<Model>("SphereHighPoly"));
			Models.Add("SphereLowPoly", Content.Load<Model>("SphereLowPoly"));


#if DEBUG
			DebugShapeRenderer.AddBoundingBox(new BoundingBox(new Vector3(-2, -2, -2), new Vector3(2, 2, 2)), Color.RosyBrown, 30);

			//Set up the reference grid
			grid = new SampleGrid();
			grid.GridColor = Color.LimeGreen;
			grid.GridScale = 1.0f;
			grid.GridSize = 32;
			grid.LoadGraphicsContent();
			//Set the grid to draw on the x/z plane around the origin
			grid.WorldMatrix = Matrix.Identity;
#endif

		}

		/// <summary>
		/// UnloadContent will be called once per game and is the place to unload
		/// all content.
		/// </summary>
		protected override void UnloadContent()
		{
		
			SharedResources.OnUnLoadContent(this);
			// TODO: Unload any non ContentManager content here
		}

		/// <summary>
		/// Allows the game to run logic such as updating the world,
		/// checking for collisions, gathering input, and playing audio.
		/// </summary>
		/// <param name="gameTime">Provides a snapshot of timing values.</param>
		protected override void Update(GameTime gameTime)
		{
			SharedResources.OnBeginUpdate(gameTime);
		
			SharedResources.OnUpdate(this);
			// TODO: Add your update logic here
#if DEBUG

			grid.ProjectionMatrix = CameraManager.ActiveCamera.Projection;
			grid.ViewMatrix = CameraManager.ActiveCamera.View;
#endif


			base.Update(gameTime);
			SharedResources.OnEndUpdate();
		}

		/// <summary>
		/// This is called when the game should draw itself.
		/// </summary>
		/// <param name="gameTime">Provides a snapshot of timing values.</param>
		protected override void Draw(GameTime gameTime)
		{
			SharedResources.Draw(this);
			//the SpriteBatch added below to draw the current technique name
			//is changing some needed render states, so they are reset here.
			this.GraphicsDevice.DepthStencilState = DepthStencilState.Default;
#if DEBUG
			//draw the reference grid so it's easier to get our bearings
			grid.Draw();
			Gimbal.Instance.Draw();
			var activeCamera = CameraManager.ActiveCamera;
			DebugShapeRenderer.Draw(gameTime, activeCamera.View, activeCamera.Projection);
#endif
			// TODO: Add your drawing code here
			//Stubbed out
			Matrix half = new Matrix(
					0.5f, 0f, 0f, 0f,
					  0f, 0.5f, 0f, 0f,
					  0f, 0f, 0.5f, 0f,
					  0f, 0f, 0f, 1f);

			int counter = -1;
			for (int y = -2; y < 2; y++)
			{
				counter = -1;
				foreach (KeyValuePair<string, Model> item in this.Models)
				{
					item.Value.Draw(CameraManager.ActiveCamera.View, CameraManager.ActiveCamera.Projection, Vector3.Zero + new Vector3(2.5f * counter, y, 0f), half);
					counter++;
				}
			}


			SharedResources.SpriteBatch.Begin();

#if DEBUG
			SharedResources.SpriteBatch.DrawString(SharedResources.DebugFont, "Debug", new Vector2(50, 50), Color.Black);
#else
			SharedResources.SpriteBatch.DrawString(SharedResources.DebugFont, "Release", new Vector2(50,50), Color.Black);
#endif
			SharedResources.SpriteBatch.End();

			base.Draw(gameTime);
		}

		public Game xnaGame
		{
			get
			{
				return this;
			}
			set
			{
				throw new NotImplementedException();
			}
		}

		public void CreateAssets()
		{
		}
	}
}

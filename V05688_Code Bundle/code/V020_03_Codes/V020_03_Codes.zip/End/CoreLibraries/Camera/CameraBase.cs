﻿using Core;
using Microsoft.Xna.Framework;

namespace Camera
{

	public abstract class CameraBase : Noun, ICamera
	{
		// Set field of view of the camera in radians (pi/4 is 45 degrees).
		protected static float viewAngle = MathHelper.PiOver4;

		// Set distance from the camera of the near and far clipping planes.
		static float nearClip = 1.0f;
		static float farClip = 2000.0f;



		protected eCameraType type;
		protected INoun target;
		protected Matrix view = Matrix.Identity, projection = Matrix.Identity;

		protected BoundingFrustum frustum;

		public BoundingFrustum Frustum
		{
			get { return frustum; }
			set { frustum = value; }
		}

		public Matrix Projection
		{
			get { return projection; }
			set { projection = value; }
		}

		public Matrix View
		{
			get { return view; }
			set { view = value; }
		}

		public eCameraType Type
		{
			get { return type; }
			set { type = value; }
		}


		public CameraBase(INoun target, Vector3 position, eCameraType type)
		{
			this.type = type;
			this.target = target;
			this.Position = position;
			// call update on the child object, filter down to base object
			this.Update();
		}

		public void Update()
		{
			frustum = new BoundingFrustum(view * projection);
		}
	}
}

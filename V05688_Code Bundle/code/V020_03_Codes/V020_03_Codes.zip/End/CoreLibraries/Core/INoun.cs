﻿using Microsoft.Xna.Framework;

namespace Core
{

	public interface INoun
	{
		/// <summary>
		/// Gets a transform matrix describing the
		/// current position Scaling Position and Rotation.
		/// </summary>
		Matrix Transform { get; set; }

		/// <summary>
		/// The position of the object
		/// </summary>
		Vector3 Position { get; set; }

		/// <summary>
		/// The direction the object is facing
		/// <para>Alternativly called Yaw</para>
		/// </summary>
		float FacingDirection { get; set; }


		Vector3 Up { get; set; }
		Vector3 Forward { get; set; }
		Vector3 Right { get; set; }

	}
}

﻿using Microsoft.Xna.Framework;

namespace Core
{
	public class Noun : INoun
	{
		/// <summary>
		/// Gets a transform matrix describing the
		/// current position Scaling and Rotation.
		/// </summary>
		public Matrix Transform
		{
			get { return transform; }
			set { this.transform = value; }
		}

		Matrix transform;


		public Vector3 Position
		{
			get
			{
				return transform.Translation;
			}
			set
			{
				transform.Translation = value;
			}
		}

		public float FacingDirection
		{
			get
			{
				return Vector3.Dot(Vector3.Forward, transform.Forward);
			}
			set
			{
				transform *= Matrix.CreateRotationY(value);
			}
		}



		public Vector3 Up
		{
			get
			{
				return this.transform.Up;
			}
			set
			{
				this.transform.Up = value;
			}
		}

		public Vector3 Forward
		{
			get
			{
				return this.transform.Forward;
			}
			set
			{
				this.transform.Forward = value;
			}
		}

		public Vector3 Right
		{
			get
			{
				return this.transform.Right;
			}
			set
			{
				this.transform.Right = value;
			}
		}
	}
}

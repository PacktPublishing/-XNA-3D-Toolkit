﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Core.Helpers;
using Camera;
using GameComponents;

namespace GraphicsDebugger
{

	public class Gimbal : IDisposable
	{
		private VertexBuffer vertexBuffer;
		private BasicEffect effect;

		private bool isDisposed;

		private static Gimbal instance = new Gimbal();
		private Gimbal()
		{
			effect = new BasicEffect(SharedResources.GraphicsDevice);
		}
		public static Gimbal Instance
		{
			get
			{
				return instance;
			}
		}

		public void UnloadGraphicsContent()
		{
			if (this.vertexBuffer != null)
			{
				vertexBuffer.Dispose();
				vertexBuffer = null;
			}
			if (effect != null)
			{
				effect.Dispose();
				effect = null;
			}
		}

		~Gimbal()
		{
			Dispose(false);
		}
		public void Dispose()
		{
			Dispose(true);
			GC.SuppressFinalize(this);
		}

		private void Dispose(bool disposing)
		{
			if (!isDisposed)
			{
				if (disposing)
				{
					//if we're manually disposing,
					//then managed content should be unloaded
					UnloadGraphicsContent();
				}
				isDisposed = true;
			}
		}

		public void Draw()
		{


			VertexPositionColor[] vertices = new VertexPositionColor[6];

			vertices[0] = new VertexPositionColor(new Vector3(1, 0, 0), Color.Red);
			vertices[1] = new VertexPositionColor(new Vector3(-1, 0, 0), Color.Red);

			vertices[2] = new VertexPositionColor(new Vector3(0, 1, 0), Color.Blue);
			vertices[3] = new VertexPositionColor(new Vector3(0, -1, 0), Color.Blue);

			vertices[4] = new VertexPositionColor(new Vector3(0, 0, 1), Color.Green);
			vertices[5] = new VertexPositionColor(new Vector3(0, 0, -1), Color.Green);


			this.vertexBuffer = new VertexBuffer(SharedResources.GraphicsDevice, typeof(VertexPositionColor),
												 6,
												 BufferUsage.WriteOnly);
			this.vertexBuffer.SetData<VertexPositionColor>(vertices);


			effect.World = Matrix.Identity;
			effect.View = CameraManager.ActiveCamera.View;
			effect.Projection = CameraManager.ActiveCamera.Projection;
			effect.VertexColorEnabled = true;
			effect.LightingEnabled = false;

			SharedResources.GraphicsDevice.SetVertexBuffer(this.vertexBuffer);

			for (int i = 0; i < this.effect.CurrentTechnique.Passes.Count; ++i)
			{
				this.effect.CurrentTechnique.Passes[i].Apply();
				SharedResources.GraphicsDevice.DrawPrimitives(PrimitiveType.LineList, 0, 3);
			}

			SharedResources.SpriteBatch.Begin();
			SharedResources.SpriteBatch.DrawString(SharedResources.DebugFont, "X",
				new Vector2(SharedResources.GraphicsDevice.Viewport.Width - 50, 50), Color.Red);
			SharedResources.SpriteBatch.DrawString(SharedResources.DebugFont, "Y",
				new Vector2(SharedResources.GraphicsDevice.Viewport.Width - 50, 75), Color.Blue);
			SharedResources.SpriteBatch.DrawString(SharedResources.DebugFont, "Z",
				new Vector2(SharedResources.GraphicsDevice.Viewport.Width - 50, 100), Color.Green);
			SharedResources.SpriteBatch.End();
		}
	}
}



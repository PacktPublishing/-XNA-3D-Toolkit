﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using Microsoft.Xna.Framework;
//using Core;
//using Physics;
//using Core.Helpers;

//namespace Camera.Stategies
//{
//    public class ChaseCamera : CameraBase, IHandlesInput, ICamera
//    {
//        /// <summary>
//        /// We may want to look just over the target, this will allow us to see (over the head) of our player.
//        /// </summary>
//        private Vector3 lookAtOffset = new Vector3(0, 0.28f, 0);

//        /// <summary>
//        /// We may want to look just down at the target, this will allow us to see from a level that is different than the target.
//        /// </summary>
//        private Vector3 lookFromOffset = new Vector3(0, 02.28f, 0);

//        private DampedOscillator mobility;

//        public ChaseCamera(INoun target)
//            // we don't calc the camera position, thats what the physics is for
//            : base(target, Vector3.Zero, eCameraType.Chase)
//        {
//            mobility = new DampedOscillator(target, this, new Vector3(2, 2, 2));
//            //now we set the camera to the equilibrim position
//            mobility.Reset();
//            //send everything in get the camera lined up. 
//            this.Update();
//        }

//        public void HandleInput()
//        {
//            //The motion of this camera is controlled in Update, by the DampedOscilator
//        }

//        public new void Update()
//        {
//            //Keep the camera behind the target
//            mobility.EquilibriumPosition = Vector3.Multiply(Matrix.CreateFromQuaternion(mobility.ImmobileBody.Rotation).Backward, mobility.EquilibriumPosition.Length());
//            mobility.Update();

//            view = Matrix.CreateLookAt(this.Position + lookFromOffset, target.Position + lookAtOffset, target.Up);
//            projection = Matrix.CreatePerspectiveFieldOfView(
//                MathHelper.PiOver4, SharedResources.GraphicsDevice.Viewport.AspectRatio, .1f, 1000f);
//            base.Update();
//        }
//    }
//}

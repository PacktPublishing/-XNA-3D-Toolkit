﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Core.IO
{
	public static class StringExtensions
	{
		public static string GetFileFromPath(this string @this) 
		{
			return   @this.Split(new char[] { '/', '\\' }).Last();
		}
		public static string GetFolderFromPath(this string @this)
		{
			return @this.Substring(0, @this.Length - @this.GetFileFromPath().Length);
		} 
	}
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Graphics;

namespace Core.HLSL
{
	public enum ShaderInput
	{
		Vector2d,
		Vector3d,
		Vector4d,
		Float,
		Matrix4x4,
		Bool,
		Int32,
		Single,
		String,
		Texture,
		Texture1D,
		Texture2D,
		Texture3D,
		TextureCube
	}
}

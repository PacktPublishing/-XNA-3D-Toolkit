﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Graphics;
using Core.Collections;
using Core.Helpers;
namespace Core.HLSL.SupportedShaders
{
	public class NormalDiffuseShader :IShader
	{
		private  Effect effect;
		public static readonly string Key = "NormalDiffuseShader";
		private NormalDiffuseShader()
		{
			ShaderLibrary.Load("Shaders/Supported/NormalSpecDiffuse", Key);
			effect = ShaderLibrary.Shaders[Key].Effect;
		}
		public Effect Effect
		{
			get { return effect; }
			set { effect = value; }
		}
		private static NormalDiffuseShader instance = new NormalDiffuseShader();

		public static NormalDiffuseShader Instance
		{
			get { return NormalDiffuseShader.instance; }
			set { NormalDiffuseShader.instance = value; }
		}

		internal static void Initialize()
		{
			//calling this loads the shader and adds all associated info to the game.
		}
	}
}

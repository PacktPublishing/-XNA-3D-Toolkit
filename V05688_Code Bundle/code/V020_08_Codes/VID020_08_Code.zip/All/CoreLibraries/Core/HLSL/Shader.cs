﻿using System;
using System.Collections.Generic;
using System.Linq;
using Core.Collections;
using Core.Helpers;
using Core.IO;
using Microsoft.Xna.Framework.Graphics;

namespace Core.HLSL
{


	public class Shader : IShader
	{
		Dictionary<string, ShaderInput> Settings = new Dictionary<string, ShaderInput>();

		public Shader(string path)
		{
			this.effect = SharedResources.ContentManager.Load<Effect>(path);
			// if the shader has associated resources...
			Dictionary<string, string> additionalFiles = new Dictionary<string, string>();
			foreach (var param in effect.Parameters)
			{
				if (param.Annotations.Count() != 0)
				{
					var annotations = param.Annotations;
					foreach (var note in annotations)
					{
						switch (note.Name)
						{
							case "filename":
								var value = note.GetValueString();
								//Assume that paths are relative
								additionalFiles.Add(
									String.Format("{0}.{1}.{2}",
										param.Name, note.Name, value),
									path.GetFolderFromPath() + value);
								break;
							default:
								//TODO Handle your content here
								break;
						}
					}
				}
			}
			//Load those files (probably mostly textures) into the Texture Library
			foreach (var kvp in additionalFiles)
			{
				TextureLibrary.Texture2dCollection.Add(kvp.Key, SharedResources.ContentManager.Load<Texture2D>(kvp.Value));
			}
		}

		private Effect effect;

		public Effect Effect
		{
			get { return effect; }
			set { effect = value; }
		}
	}
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Graphics;

namespace Core.Collections
{
	public static class TextureLibrary
	{
		public static Dictionary<string, Texture2D> Texture2dCollection = new Dictionary<string, Texture2D>();
	}
}

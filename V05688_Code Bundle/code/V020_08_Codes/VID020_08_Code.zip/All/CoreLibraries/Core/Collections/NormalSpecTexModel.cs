﻿using System;
using Core.GraphicsStructures;
using Core.Helpers;
using Core.HLSL;
using Core.HLSL.SupportedShaders;
using Core.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Core.Collections
{
	/// <summary>
	/// Shader that calculates specular from the normal.
	/// </summary>
	public class NormalDiffuseModel:SimpleModel
	{
		string diffuseKey, normalKey;

		public NormalDiffuseModel(string path,  string normalPath, string diffusePath):base(path)
		{
			NormalDiffuseShader.Initialize();


			diffuseKey = diffusePath.GetFileFromPath();
			if (!TextureLibrary.Texture2dCollection.ContainsKey(diffuseKey))
			{
				TextureLibrary.Texture2dCollection.Add(diffuseKey,
				   SharedResources.ContentManager.Load<Texture2D>(diffusePath)
				   );
			}
			normalKey = normalPath.GetFileFromPath();
			if (!TextureLibrary.Texture2dCollection.ContainsKey(normalKey))
			{
				TextureLibrary.Texture2dCollection.Add(normalKey,
					SharedResources.ContentManager.Load<Texture2D>(normalPath)
					);
			}
		}

		public NormalDiffuseModel(string path,  string normalpath, string diffusePath, Matrix[] transforms)
			:this(path,  normalpath, diffusePath)
		{
			this.instances = new ModelInfo[transforms.Length];
			for (int i = 0; i < this.instances.Length; i++)
			{
				this.instances[i] = new ModelInfo(transforms[i], ModelInfoHelper.ConstructUnitBounds(transforms[i].Translation)); 
			}
			
		}

		public NormalDiffuseModel(string path, string normalpath, string diffusePath, Matrix[] transforms, int? drawOrderSuggestion)
			: this(path, normalpath, diffusePath, transforms)
		{
			this.SuggestedDrawOrder = drawOrderSuggestion;
		}


		/// <summary>
		/// Draws using a custom light
		/// </summary>
		/// <param name="viewMatrix"></param>
		/// <param name="projectionMatrix"></param>
		/// <param name="index"></param>
		/// <param name="light"></param>
		public void Draw(Matrix viewMatrix, Matrix projectionMatrix, int index, ILight light)
		{
			Vector4 lightColor = new Vector4(1, 1, 1, 1);
			Vector4 ambientLightColor = new Vector4(.2f, .2f, .2f, 1);
			NormalDiffuseShader.Instance.Effect.Parameters["LightPosition"].SetValue(light.LightSourcePosition);
			NormalDiffuseShader.Instance.Effect.Parameters["LightColor"].SetValue(lightColor);
			NormalDiffuseShader.Instance.Effect.Parameters["AmbientLightColor"].SetValue(ambientLightColor);
			this.DrawCore(viewMatrix, projectionMatrix, index);
		}
		/// <summary>
		/// Draws using default lighting
		/// </summary>
		/// <param name="viewMatrix"></param>
		/// <param name="projectionMatrix"></param>
		/// <param name="index"></param>
		public new void Draw(Matrix viewMatrix, Matrix projectionMatrix, int index)
		{
			Vector4 lightColor = new Vector4(1, 1, 1, 1);
			Vector4 ambientLightColor = new Vector4(.2f, .2f, .2f, 1);
			NormalDiffuseShader.Instance.Effect.Parameters["LightColor"].SetValue(lightColor);
			NormalDiffuseShader.Instance.Effect.Parameters["AmbientLightColor"].SetValue(ambientLightColor);
			this.DrawCore(viewMatrix, projectionMatrix, index);
		}
		private void DrawCore(Matrix viewMatrix, Matrix projectionMatrix, int index)
		{
			NormalDiffuseShader.Instance.Effect.Parameters["DiffuseTexture"].SetValue(TextureLibrary.Texture2dCollection[diffuseKey]);
			NormalDiffuseShader.Instance.Effect.Parameters["NormalTexture"].SetValue(TextureLibrary.Texture2dCollection[normalKey]);
			float shininess = .3f;
			float specularPower = 4.0f;
			NormalDiffuseShader.Instance.Effect.Parameters["Shininess"].SetValue(shininess);
			NormalDiffuseShader.Instance.Effect.Parameters["SpecularPower"].SetValue(specularPower);
			this.model.DrawWithShader(viewMatrix, projectionMatrix, this.instances[index].World.Translation, this.instances[index].World, NormalDiffuseShader.Instance);

		}

	}
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

namespace Core
{
	public interface ILight
	{
		//feeds into Shader As float3 LightPosition;
		Vector3 LightSourcePosition { get; }

		#region Not wired into the shader
		float LightIntensity { get; set; }
		Color LightColor { get; set; }
		Color AmbientLightColor { get; set; }
		#endregion
	}
}

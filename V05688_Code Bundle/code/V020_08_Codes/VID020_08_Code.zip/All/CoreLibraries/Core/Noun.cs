﻿using Microsoft.Xna.Framework;
using Core.Helpers;
using System;

namespace Core
{
	public class Noun : INoun
	{
		Matrix transform = Matrix.Identity;
		Quaternion rotation =  Quaternion.Identity; 

		/// <summary>
		/// A transform matrix describing the
		/// current position Scaling Position and Rotation.
		/// </summary>
		public Matrix Transform
		{
			get { return transform; }
			set { this.transform = value; }
		}
		/// <summary>
		/// A Quaternion describing the
		/// current Rotation of the object.
		/// </summary>
		public Quaternion Rotation
		{
			get { return rotation; }
			set { this.rotation = value; }
		}
		public Vector3 Position
		{
			get
			{
				return transform.Translation;
			}
			set
			{
				transform.Translation = value;
			}
		}

		public Vector3 Up
		{
			get
			{
				return Matrix.CreateFromQuaternion(this.Rotation).Up;
			}
		}

		public Vector3 Forward
		{
			get
			{
				return Matrix.CreateFromQuaternion(this.Rotation).Forward;
			}
		}

		public Vector3 Right
		{
			get
			{
				return Matrix.CreateFromQuaternion(this.Rotation).Right;
			}
		}


		public void RotateLocalY(float turnAmount)
		{
			this.rotation.RotateLocalY(out this.rotation, turnAmount);
		}
		/// <summary>
		/// This is up and down WRT local Right (in the direction of Facing
		/// </summary>
		/// <param name="turnAmount"></param>
		public void RotateUpDown(float turnAmount)
		{
			this.rotation.RotateUpDown(out this.rotation, turnAmount);
		}
		/// <summary>
		/// This is up and down WRT local Right (in the direction of Facing
		/// </summary>
		/// <param name="turnAmount"></param>
		public void RotateLeftRight(float turnAmount)
		{
			this.rotation.RotateLeftRight(out this.rotation, turnAmount);
		}
	}
}


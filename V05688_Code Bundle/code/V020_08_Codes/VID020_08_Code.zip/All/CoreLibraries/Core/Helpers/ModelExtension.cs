﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Core.HLSL;

namespace Core.Helpers
{
	public static class ModelExtensions
	{
		public static void Draw(this Model @this,
				Matrix viewMatrix,
				Matrix projectionMatrix,
				Vector3 position,
				Matrix scalingRotation
				)
		{

			// Copy any parent transforms.
			Matrix[] transforms = new Matrix[@this.Bones.Count];
			@this.CopyAbsoluteBoneTransformsTo(transforms);

			// Draw the model. A model can have multiple meshes, so loop.
			foreach (ModelMesh mesh in @this.Meshes)
			{
				// This is where the mesh orientation is set, as well 
				// as our camera and projection.
				foreach (BasicEffect effect in mesh.Effects)
				{
					effect.World = transforms[mesh.ParentBone.Index] *
						scalingRotation
						* Matrix.CreateTranslation(position);
					effect.View = viewMatrix;
					effect.Projection = projectionMatrix;

					effect.EnableDefaultLighting();
					effect.PreferPerPixelLighting = true;

					// Set the fog to match the black background color
					effect.FogEnabled = true;
					effect.FogColor = Vector3.Zero;
					effect.FogStart = 10000;
					effect.FogEnd = 320000;
				}
				// Draw the mesh, using the effects set above.
				mesh.Draw();
			}
		}

		public static void Draw(this Model @this,
				Matrix viewMatrix,
				Matrix projectionMatrix,
				Vector3 position,
				Matrix transform, 
				Quaternion rotation
				)
		{

			// Copy any parent transforms.
			Matrix[] transforms = new Matrix[@this.Bones.Count];
			@this.CopyAbsoluteBoneTransformsTo(transforms);

			// Draw the model. A model can have multiple meshes, so loop.
			foreach (ModelMesh mesh in @this.Meshes)
			{
				// This is where the mesh orientation is set, as well 
				// as our camera and projection.
				foreach (BasicEffect effect in mesh.Effects)
				{
					effect.World = transforms[mesh.ParentBone.Index] *
						Matrix.CreateFromQuaternion(rotation)*
						Matrix.CreateTranslation(position);
					effect.View = viewMatrix;
					effect.Projection = projectionMatrix;

					effect.EnableDefaultLighting();
					effect.PreferPerPixelLighting = true;

					// Set the fog to match the black background color
					effect.FogEnabled = true;
					effect.FogColor = Vector3.Zero;
					effect.FogStart = 10000;
					effect.FogEnd = 320000;
				}
				// Draw the mesh, using the effects set above.
				mesh.Draw();
			}
		}

		public static void DrawWithShader(this Model @this,
				Matrix viewMatrix,
				Matrix projectionMatrix,
				Vector3 position,
				Matrix scalingRotation, 
				IShader shader
				)
		{

			// Copy any parent transforms.
			Matrix[] transforms = new Matrix[@this.Bones.Count];
			@this.CopyAbsoluteBoneTransformsTo(transforms);

			// Draw the model. A model can have multiple meshes, so loop.
			foreach (ModelMesh mesh in @this.Meshes)
			{
					foreach (ModelMeshPart part in mesh.MeshParts)
					{
						part.Effect = shader.Effect;
						shader.Effect.Parameters["World"].SetValue(
						Matrix.CreateTranslation(position));
						shader.Effect.Parameters["View"].SetValue(viewMatrix);
						shader.Effect.Parameters["Projection"].SetValue(projectionMatrix);
						
					}
					mesh.Draw();
				}
			}
		
	}
}

﻿using Microsoft.Xna.Framework;

namespace Core.Helpers
{
	public static class QuaternionExtensions
	{
		/// <summary>
		/// Rotate the Quaterion on it's own Axis
		/// </summary>
		/// <param name="this"></param>
		/// <param name="yaw">Rotation around the Y Axis (UP)</param>
		/// <param name="pitch">Rotation around the X axis</param>
		/// <param name="roll">Rotation around the Z axis</param>
		public static void Rotate(this Quaternion @this,out Quaternion result, float yaw, float pitch, float roll)
		{
			Matrix rotMat = Matrix.CreateFromQuaternion(@this);

			result = @this *
				Quaternion.CreateFromAxisAngle(
					Vector3.Transform(Vector3.Right, rotMat), pitch) *
				Quaternion.CreateFromAxisAngle(
					Vector3.Transform(Vector3.Up, rotMat), yaw) *
				Quaternion.CreateFromAxisAngle(
					Vector3.Transform(Vector3.Backward, rotMat), roll);
			result.Normalize();
		}
		/// <summary>
		/// Rotate the Quaterion on it's own Y Axis
		/// </summary>
		/// <param name="this"></param>
		/// <param name="yaw">Rotation around the Y Axis (UP)</param>
		public static void RotateLocalY(this Quaternion @this,out Quaternion result, float yaw)
		{
			Rotate(@this,out result, yaw, 0, 0);
		}
		/// <summary>
		/// Rotate the Quaterion on it's own Right Axis
		/// </summary>
		/// <param name="this"></param>
		/// <param name="yaw">Rotation around the Right Axis </param>
		public static void RotateUpDown(this Quaternion @this, out Quaternion result, float upDown)
		{
			Matrix rotMat = Matrix.CreateFromQuaternion(@this);

			result = @this *
				Quaternion.CreateFromAxisAngle( Vector3.Right, upDown) ;
			result.Normalize();
		}
		/// <summary>
		/// Rotate the Quaterion on it's own Right Axis
		/// </summary>
		/// <param name="this"></param>
		/// <param name="yaw">Rotation around the Right Axis (UP)</param>
		public static void RotateLeftRight(this Quaternion @this, out Quaternion result, float leftRight)
		{
			result = @this *
				Quaternion.CreateFromAxisAngle(Vector3.Up, leftRight);
			result.Normalize();
		}
	}
}

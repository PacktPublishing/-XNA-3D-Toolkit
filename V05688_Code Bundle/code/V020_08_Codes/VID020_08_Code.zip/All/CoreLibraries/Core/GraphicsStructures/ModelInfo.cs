﻿using Microsoft.Xna.Framework;
using System;

namespace Core.GraphicsStructures
{
	public struct ModelInfo
	{
		public Matrix World;
		public BoundingBox Bounds;
		public ModelInfo(Matrix world, BoundingBox bounds) 
		{
			if (bounds.Contains(world.Translation)== ContainmentType.Contains)
			{
				this.World = world;
				this.Bounds = bounds;
			}
			else { throw new Exception("cannot add bounding box that doesn't contain object, use ModelInfoHelper"); }
			}
	}
	public static class ModelInfoHelper
	{
		public static BoundingBox ConstructBounds(Vector3 position, Vector3 min, Vector3 max)
		{
			return new BoundingBox(min + position, max + position);
		}
		public static BoundingBox ConstructUnitBounds(Vector3 position)
		{
			return new BoundingBox(new Vector3(-0.5f, -0.5f, -0.5f) + position, new Vector3(0.5f, 0.5f, 0.5f) + position);
		}
	}
}

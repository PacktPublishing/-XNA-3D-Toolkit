﻿
#if WINDOWS||XBOX
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Particle3DSample;
using Core;

namespace GameComponents.ParticleEngine.ParticleSystems
{
	public class FirePillarParticleSystem : ParticleSystem, INoun
	{
		private float radius;

		public float Radius
		{
			get { return radius; }
			set { radius = value; }
		}
		private Vector3 position;
		public FirePillarParticleSystem(Vector3 pos, float radius) 
		{
			this.position = pos;
			this.radius = radius;
		}
		private float scale = 1;

		protected override void InitializeSettings(ParticleSettings settings)
		{
			settings.TextureName = "fire";

			settings.MaxParticles = 2400;

			settings.Duration = TimeSpan.FromSeconds(2);

			settings.DurationRandomness = 1;

			settings.MinHorizontalVelocity = 0.000005f;
			settings.MaxHorizontalVelocity = 0.001F;

			settings.MinVerticalVelocity = -1f * scale;
			settings.MaxVerticalVelocity = 1 * scale;

			// Set gravity upside down, so the flames will 'fall' upward.
			settings.Gravity = new Vector3(0, 15 * scale, 0);

			settings.MinColor = new Color(255, 255, 255, 10);
			settings.MaxColor = new Color(255, 255, 255, 40);

			//settings.MinStartSize = 0.01f * scale;
			//settings.MaxStartSize = 0.1f * scale;

			settings.MinStartSize = 1;
			settings.MaxStartSize = 5;

			settings.MinEndSize = 0.01F;
			settings.MaxEndSize = 7;
			//settings.MinEndSize = 0.5f * scale;
			//settings.MaxEndSize = 1 * scale;

			// Use additive blending.
			settings.BlendState = BlendState.Additive;
		}

		public Matrix Transform
		{
			get
			{
				throw new NotImplementedException();
			}
			set
			{
				throw new NotImplementedException();
			}
		}

		public Quaternion Rotation
		{
			get
			{
				throw new NotImplementedException();
			}
			set
			{
				throw new NotImplementedException();
			}
		}

		public Vector3 Position { get { return this.position; } set { this.position = value; } }

		public Vector3 Up
		{
			get { return Vector3.Up; }
		}

		public Vector3 Forward
		{
			get { return Vector3.UnitX; }
		}

		public Vector3 Right
		{
			get { return Vector3.UnitZ; }
		}
	}
}

#endif

﻿using System;
using System.Collections.Generic;
using System.Linq;
using Camera;
using Core.Collections;
using Core.GraphicsStructures;
using Core.Helpers;
using GameComponents.DrawOrderManagerSupportItems;
using GameComponents.Enumerations;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;

namespace GameComponents
{
	public class DrawOrderManager : DrawableGameComponent
	{
		public new Game Game
		{
			get { return base.Game; }
		}

		private List<DrawOrder> drawOrder = new List<DrawOrder>();

		private static Dictionary<string, SimpleModel> models = new Dictionary<string, SimpleModel>();

		private static Dictionary<string, InstancedModel> instancedModels = new Dictionary<string, InstancedModel>();

		private static Dictionary<string, Cube> cubes = new Dictionary<string, Cube>();

		private static Dictionary<string, NormalDiffuseModel> normalSpecDiffuseModels = new Dictionary<string, NormalDiffuseModel>();

		[ContentSerializerIgnore]
		public Dictionary<string, SimpleModel> Models { get { return models; } set { models = value; } }

		[ContentSerializerIgnore]
		public Dictionary<string, InstancedModel> InstancedModels { get { return instancedModels; } set { instancedModels = value; } }

		public Dictionary<string, Cube> CubesModels { get { return cubes; } set { cubes = value; } }

		[ContentSerializerIgnore]
		public Dictionary<string, NormalDiffuseModel> NormalSpecDiffusModels { get { return normalSpecDiffuseModels; } set { normalSpecDiffuseModels = value; } }




		public static void Add(eModelType type, string assetName, string assetPath)
		{
			switch (type)
			{
				case eModelType.Simple:
					models.Add(assetName, new SimpleModel(assetPath));
					break;
				case eModelType.Instanced:
					instancedModels.Add(assetName, new InstancedModel(assetPath));
					break;
				case eModelType.Cube:
					switch (assetName)
					{
						case "Default":
							cubes.Add(assetName, Cubes.Make(Vector3.Zero, eCubeType.Default));
							break;
						case "Metal":
							cubes.Add(assetName, Cubes.Metalic(Vector3.Zero));
							break;
						case "Psychadelic":
							cubes.Add(assetName, Cubes.Psychadelic(Vector3.Zero));
							break;
						default:
							cubes.Add(assetName, Cubes.Make(Vector3.Zero, assetPath));
							break;
					}
					break;
				case eModelType.NormalSpecDiffuseModel:
					throw new NotSupportedException("NormalSpecDiffuseModel must be created with textures associated use AddNormalSpecDiffuseModel() instead.");
					break;
				default:
					break;
			}
		}
		public static void Add(eModelType type, string assetName, string assetPath, Matrix[] locations)
		{
			switch (type)
			{
				case eModelType.Simple:
					models.Add(assetName, new SimpleModel(assetPath, locations));
					break;
				case eModelType.Instanced:
					instancedModels.Add(assetName, new InstancedModel(assetPath, locations));
					break;
				case eModelType.Cube:
					switch (assetName)
					{
						case "Default":

							foreach (var matrix in locations)
							{
								cubes.Add(assetName, Cubes.Make(matrix.Translation, eCubeType.Default));
							}
							break;
						case "Metalic":

							foreach (var matrix in locations)
							{
								cubes.Add(assetName, Cubes.Metalic(matrix.Translation));
							}
							break;
						case "Psychadelic":

							foreach (var matrix in locations)
							{
								cubes.Add(assetName, Cubes.Psychadelic(matrix.Translation));
							}
							break;
					}
					break;
				case eModelType.NormalSpecDiffuseModel:
					throw new NotSupportedException("NormalSpecDiffuseModel must be created with textures associated use AddNormalSpecDiffuseModel() instead.");
					break;
				default:
					break;
			}
		}
		public static void AddNormalDiffuseModel(string assetName, string assetPath, string normalPath, string diffusePath)
		{
			normalSpecDiffuseModels.Add(assetName,
				new NormalDiffuseModel(assetPath, normalPath, diffusePath));
		}
		public static void AddNormalDiffuseModel(string assetName, string assetPath, string normalPath, string diffusePath, Matrix[] locations)
		{
			normalSpecDiffuseModels.Add(assetName,
				new NormalDiffuseModel(assetPath, normalPath, diffusePath, locations));
		}
		public static void AddNormalDiffuseModel(string assetName, string assetPath, string normalPath, string diffusePath, Matrix[] locations, int? drawOrderSuggestion)
		{
			normalSpecDiffuseModels.Add(assetName,
				new NormalDiffuseModel(assetPath, normalPath, diffusePath, locations, drawOrderSuggestion));
		}
		public DrawOrderManager()
			: base(SharedResources.Game)
		{
			// TODO: Construct any child components here

		}

		/// <summary>
		/// Allows the game component to perform any initialization it needs to before starting
		/// to run.  This is where it can query for any required services and load content.
		/// </summary>
		public override void Initialize()
		{
			base.Initialize();
		}


		/// <summary>
		/// Allows the game component to update itself.
		/// </summary>
		/// <param name="gameTime">Provides a snapshot of timing values.</param>
		public override void Update(GameTime gameTime)
		{
			ICamera camera = CameraManager.ActiveCamera;


			drawOrder.Clear();
			foreach (var model in models)
			{
				for (int i = 0; i < model.Value.Instances.Length; i++)
				{
					if (model.Value.Instances[i].Bounds.Intersects(camera.Frustum))
					{
						drawOrder.Add(new DrawOrder(eModelType.Simple, model.Key, null, model.Value.Instances[i].World.Translation, i));
					}
				}
			}

			foreach (var model in instancedModels)
			{
				for (int i = 0; i < model.Value.Instances.Length; i++)
				{
					if (model.Value.Instances[i].Bounds.Intersects(camera.Frustum))
					{
						//if any one model is included they all are...
						drawOrder.Add(new DrawOrder(eModelType.Instanced, model.Key, null, model.Value.Instances[i].World.Translation, i));
						break;
					}
				}
			}
			foreach (var model in cubes)
			{

				if (model.Value.Info.Bounds.Intersects(camera.Frustum))
				{
					//if any one model is included they all are...
					drawOrder.Add(new DrawOrder(eModelType.Cube, model.Key, null, model.Value.Info.World.Translation, null));

				}

			}

			foreach (var model in normalSpecDiffuseModels)
			{
				for (int i = 0; i < model.Value.Instances.Length; i++)
				{
					if (model.Value.SuggestedDrawOrder.HasValue)
					{//Add the model to that position
						drawOrder.Add(new DrawOrder(eModelType.NormalSpecDiffuseModel, model.Key, model.Value.SuggestedDrawOrder.Value, model.Value.Instances[i].World.Translation, i));
					}
					else if (model.Value.Instances[i].Bounds.Intersects(camera.Frustum))
					{
						drawOrder.Add(new DrawOrder(eModelType.NormalSpecDiffuseModel, model.Key, null, model.Value.Instances[i].World.Translation, i));
					}
				}
			}

#if WINDOWS || WINDOWS_PHONE
			Sort(camera.Position);
#endif

			base.Update(gameTime);
		}




		public override void Draw(GameTime gameTime)
		{
			foreach (var item in drawOrder)
			{
				switch (item.Type)
				{
					case eModelType.Simple:
						models[item.Key].Draw(CameraManager.ActiveCamera.View, CameraManager.ActiveCamera.Projection, item.InstanceIndex.Value);
						break;
					case eModelType.Instanced:
						instancedModels[item.Key].Draw(CameraManager.ActiveCamera.View, CameraManager.ActiveCamera.Projection);
						break;
					case eModelType.Cube:
						cubes[item.Key].Draw(CameraManager.ActiveCamera.View, CameraManager.ActiveCamera.Projection);
						break;
					case eModelType.NormalSpecDiffuseModel:
						normalSpecDiffuseModels[item.Key].Draw(CameraManager.ActiveCamera.View, CameraManager.ActiveCamera.Projection, item.InstanceIndex.Value, LightingManager.LightSources[0]);
						break;
					default:
						break;
				}
			}

#if DEBUG
			SharedResources.SpriteBatch.Begin();
			SharedResources.SpriteBatch.DrawString(SharedResources.DebugFont, String.Format("Drawing {0} models", drawOrder.Count.ToString()), new Vector2(200, 200), Color.Teal);
			SharedResources.SpriteBatch.End();
#endif
			base.Draw(gameTime);
		}

		protected override void LoadContent()
		{
			//Handel Child object content loading
			Cubes.LoadContent();


			base.LoadContent();
		}
		public static List<BoundingBox> GetBoundingBoxes(eModelType type)
		{
			List<BoundingBox> retval = new List<BoundingBox>();
			switch (type)
			{
				case eModelType.Simple:
					foreach (var m in models) { foreach (var item in m.Value.Instances) { retval.Add(item.Bounds); } }
					break;
				case eModelType.Instanced:
					foreach (var m in instancedModels) { foreach (var item in m.Value.Instances) { retval.Add(item.Bounds); } }
					break;
				case eModelType.Cube:
					foreach (var m in cubes) { retval.Add(m.Value.Info.Bounds); }
					break;
				case eModelType.NormalSpecDiffuseModel:
					foreach (var m in normalSpecDiffuseModels) { foreach (var item in m.Value.Instances) { retval.Add(item.Bounds); } }
					break;
				default:
					break;
			}
			return retval;
		}
		private void Sort(Vector3 origin)
		{
			DrawOrderManagerSupportItems.DrawOrder.CurrentOrigin = origin;
			var temp = OrganizeAndSort(drawOrder);
			foreach (var item in temp)
			{
				item.Sort(DrawOrderManagerSupportItems.DrawOrder.VectorCompareer);
			}
			drawOrder.Clear();
			foreach (var item in temp)
			{
				foreach (var thing in item)
				{
					drawOrder.Add(thing);
				}
			}
		}


		private static List<List<DrawOrder>> OrganizeAndSort(List<DrawOrder> raw)
		{
			List<List<DrawOrder>> retval = new List<List<DrawOrder>>();
#if XBOX
			retval.Add(raw);
			return retval;
#endif

			raw.Sort();
			List<DrawOrder> temp;
			for (int a = 0; a < raw.Count; a++)
			{
				temp = raw.Where(x => x.LayerIndex.HasValue ? x.LayerIndex.Value == a : false).ToList();
				if (temp.Count > 0)
				{
					retval.Add(temp);
				}
				temp = null;
			}
			temp = raw.Where(x => !x.LayerIndex.HasValue).ToList();
			if (temp.Count > 0)
			{
				retval.Add(temp);
			}
			return retval;

		}
	}
}

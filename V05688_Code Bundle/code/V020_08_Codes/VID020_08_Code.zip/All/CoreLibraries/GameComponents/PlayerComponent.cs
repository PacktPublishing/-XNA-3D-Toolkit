﻿using Core;
using Core.Helpers;
using Microsoft.Xna.Framework;
using System;

namespace GameComponents
{
	public class PlayerComponent : DrawableGameComponent, IHandlesInput
	{
		private IPlayer player;

		public IPlayer Player
		{
			get { return player; }
			set { player = value; }
		}

		public PlayerComponent(IPlayer plyr)
			: base(SharedResources.Game)
		{
			this.player = plyr;
		}

		public void HandleInput()
		{
			player.HandleInput();
		}
		protected override void LoadContent()
		{
			player.LoadContent();
			base.LoadContent();
		}
		public override void Draw(GameTime gameTime)
		{
			
			player.Draw(CameraManager.ActiveCamera.View, CameraManager.ActiveCamera.Projection);
			var sb = SharedResources.SpriteBatch;
			base.Draw(gameTime);
			sb.Begin();
			sb.DrawString(SharedResources.DebugFont, String.Format("{0} : {1}", "Player", player.Position.ToString()), new Vector2(10, 10), Color.Black);
			sb.End();
		}
		public override void Update(GameTime gameTime)
		{
			player.Update();
			base.Update(gameTime);
		}
		protected override void UnloadContent()
		{
			player.UnLoadContent();
			base.UnloadContent();
		}

	}

}

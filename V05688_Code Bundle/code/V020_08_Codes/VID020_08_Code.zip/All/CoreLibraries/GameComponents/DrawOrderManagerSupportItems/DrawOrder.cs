﻿using System;
using GameComponents.Enumerations;
using Microsoft.Xna.Framework;

namespace GameComponents.DrawOrderManagerSupportItems
{
	internal struct DrawOrder:IComparable<DrawOrder>
	{
		public eModelType Type;
		public string Key;
		//this will be null in certain cases....
		public int? LayerIndex, InstanceIndex;
		public Vector3 Position;
		public DrawOrder(eModelType type, string key, int? drawindex, Vector3 position, int? instanceIndex)
		{
			this.Type = type;
			this.Key = key;
			this.LayerIndex = drawindex;
			this.Position = position;
			this.InstanceIndex = instanceIndex;
		}
		public override string ToString()
		{
			return string.Format("{0},{1},{2}", Type.ToString(), Key, LayerIndex.HasValue ? LayerIndex.Value.ToString() : "null");
		}


		public int CompareTo(DrawOrder other)
		{
			return this.LayerIndex.HasValue ? (other.LayerIndex.HasValue ? (this.LayerIndex.Value > other.LayerIndex ? 1 : -1) : -1) : 0;
		}
		public static Vector3 CurrentOrigin;
		public static int VectorCompareer(DrawOrder a, DrawOrder b) 
		{
			if (a.Position == b.Position) { return 0; }
			return Vector3.Distance(CurrentOrigin, a.Position) > Vector3.Distance(CurrentOrigin, b.Position) ? 1 : -1;
		}
	}
}


﻿using System.Collections.Generic;
using Core;

namespace GameComponents
{
	public static class LightingManager
	{
		public static List<ILight> LightSources = new List<ILight>();

		public static void Update()
		{
			foreach (IUpdate light in LightSources) { light.Update(); }
		}
	}
}


﻿
using Core.Helpers;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Physics;

namespace Core.Tokens
{
	public class SnowmanToken : INoun, IPlayer
	{
		Noun[] parts = new Noun[] { new Noun(), new Noun() };
		Matrix sphereRollingMatrix = Matrix.Identity;
		DampedOscillator snowmanSpine;
		Model sphere;

		// This constant controls how quickly the sphere can move forward and backward
		const float SphereVelocity = 0.2f;

		// how quickly the sphere can turn from side to side
		const float SphereTurnSpeed = .025f;

		// the radius of the sphere. We'll use this to keep the sphere above the ground,
		// and when computing how far the sphere has rolled.
		const float SphereRadius = 0.05f;

		public SnowmanToken()
		{
			snowmanSpine = new DampedOscillator(parts[0], parts[1], new Vector3(0, 0.6f, 0));
			snowmanSpine.Stiffness = 85000f;
			snowmanSpine.Damping = 2500f;
			this.parts[1].Position += new Vector3(0, 0.6f, 0);
		}


		public void HandleInput()
		{

			// Now move the sphere. First, we want to check to see if the sphere should
			// turn. turnAmount will be an accumulation of all the different possible
			// inputs.
			float turnAmount = -SharedResources.CurrentGamePadState.ThumbSticks.Left.X;
			if (SharedResources.CurrentKeyboardState.IsKeyDown(Keys.A) ||
				SharedResources.CurrentKeyboardState.IsKeyDown(Keys.J) ||
				SharedResources.CurrentKeyboardState.IsKeyDown(Keys.Left) ||
				SharedResources.CurrentGamePadState.DPad.Left == ButtonState.Pressed)
			{
				turnAmount += 1;
			}
			if (SharedResources.CurrentKeyboardState.IsKeyDown(Keys.D) ||
				SharedResources.CurrentKeyboardState.IsKeyDown(Keys.H) ||
				SharedResources.CurrentKeyboardState.IsKeyDown(Keys.Right) ||
				SharedResources.CurrentGamePadState.DPad.Right == ButtonState.Pressed)
			{
				turnAmount -= 1;
			}

			if (turnAmount != 0.0f)
			{
				this.parts[0].RotateLeftRight(turnAmount * SphereTurnSpeed);
				this.parts[1].RotateLeftRight(turnAmount * SphereTurnSpeed);
			}

			// Next, we want to move the sphere forward or back. to do this, 
			// we'll create a Vector3 and modify use the user's input to modify the Z
			// component, which corresponds to the forward direction.
			Vector3 movement = Vector3.Zero;
			movement.Z = -SharedResources.CurrentGamePadState.ThumbSticks.Left.Y;

			if (SharedResources.CurrentKeyboardState.IsKeyDown(Keys.W) ||
				SharedResources.CurrentKeyboardState.IsKeyDown(Keys.Up) ||
				SharedResources.CurrentGamePadState.DPad.Up == ButtonState.Pressed)
			{
				movement.Z = -1;
			}
			if (SharedResources.CurrentKeyboardState.IsKeyDown(Keys.S) ||
				SharedResources.CurrentKeyboardState.IsKeyDown(Keys.Down) ||
				SharedResources.CurrentGamePadState.DPad.Down == ButtonState.Pressed)
			{
				movement.Z = 1;
			}

			// next, we'll create a rotation matrix from the sphereFacingDirection, and
			// use it to transform the vector. If we didn't do this, pressing "up" would
			// always move the ball along +Z. By transforming it, we can move in the
			// direction the sphere is "facing."
			Matrix sphereFacingMatrix = Matrix.CreateFromQuaternion(this.parts[0].Rotation);
			Vector3 velocity = Vector3.Transform(movement, sphereFacingMatrix);
			velocity *= SphereVelocity;

			// Now we know how much the user wants to move. We'll construct a temporary
			// vector, newSpherePosition, which will represent where the user wants to
			// go. If that value is on the heightmap, we'll allow the move.
			Vector3 newSpherePosition = this.parts[0].Position + velocity;


			// now we need to roll the ball "forward." to do this, we first calculate
			// how far it has moved.
			float distanceMoved = Vector3.Distance(this.parts[0].Position, newSpherePosition);

			// The length of an arc on a circle or sphere is defined as L = theta * r,
			// where theta is the angle that defines the arc, and r is the radius of
			// the circle.
			// we know L, that's the distance the sphere has moved. we know r, that's
			// our constant "sphereRadius". We want to know theta - that will tell us
			// how much to rotate the sphere. we rearrange the equation to get...
			float theta = distanceMoved / SphereRadius;

			// now that we know how much to rotate the sphere, we have to figure out 
			// whether it will roll forward or backward. We'll base this on the user's
			// input.
			int rollDirection = movement.Z > 0 ? 1 : -1;

			// finally, we'll roll it by rotating around the sphere's "right" vector.
			sphereRollingMatrix *= Matrix.CreateFromAxisAngle(sphereFacingMatrix.Right,
				theta * rollDirection);

			// once we've finished all computations, we can set spherePosition to the
			// new position that we calculated.
			this.parts[0].Position = newSpherePosition;

			if (SharedResources.CurrentKeyboardState.IsKeyDown(Keys.U))
			{
				this.parts[1].RotateUpDown(SphereTurnSpeed);
			}
			if (SharedResources.CurrentKeyboardState.IsKeyDown(Keys.N))
			{
				this.parts[1].RotateUpDown(-SphereTurnSpeed);
			}
		}


		public void Draw(Matrix viewMatrix, Matrix projectionMatrix)
		{
			sphere.Draw(Matrix.CreateScale(0.05f, 0.05f, 0.05f) * sphereRollingMatrix * Matrix.CreateTranslation(this.parts[0].Position), viewMatrix, projectionMatrix);
			sphere.Draw(Matrix.CreateScale(0.025f, 0.025f, 0.025f) * this.parts[1].Transform, viewMatrix, projectionMatrix);

		}


		public void LoadContent()
		{
			this.sphere = SharedResources.ContentManager.Load<Model>("PlayerTokens/sphere");
		}

		public void UnLoadContent()
		{
			//Do Nothing Here
			//TODO: Add your Custom Content Unload here
		}

		public void Update()
		{
			this.HandleInput();
			snowmanSpine.Update();
		}


		public Matrix Transform
		{
			get { return parts[0].Transform; }
			set { parts[0].Transform = value; }
		}

		public Quaternion Rotation
		{
			get { return parts[0].Rotation; }
			set { parts[0].Rotation = value; }
		}

		public Vector3 Position
		{
			get { return parts[0].Position; }
			set { parts[0].Position = value; }
		}

		public Vector3 Up
		{
			get { return parts[0].Up; }
		}

		public Vector3 Forward
		{
			get { return parts[0].Forward; }
		}

		public Vector3 Right
		{
			get { return parts[0].Right; }
		}

		public INoun Head
		{
			get { return parts[1]; }
			set
			{
				parts[0].Rotation = value.Rotation;
				parts[0].Transform = value.Transform;
			}
		}
	}
}


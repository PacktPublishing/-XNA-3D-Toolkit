using System;
using System.Collections.Generic;
using Camera;
using Camera.Stategies;
using Core.Collections;
using Core.Helpers;
using Core.Helpers.Interfaces;
using Core.HLSL;
using Core.Tokens;
using GameComponents;
using GameComponents.Enumerations;
using GameComponents.Lighting;
using GraphicsDebugger;
using GraphicsDebugger.GameComponentExtensions;
using Microsoft.CollisionSample;
using Microsoft.ShapeRenderingSample;
using Microsoft.VertexLightingSample;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

#if WINDOWS||XBOX
using GameComponents.ParticleEngine;
#endif
#if DEBUG
using System.Linq;
using System.IO;
using System.Xml.Serialization;
using System.Xml;
using Microsoft.Xna.Framework.Input;
#if WINDOWS
using Microsoft.Xna.Framework.Content.Pipeline.Serialization.Intermediate;
#endif
#endif
namespace StarterGame
{
	/// <summary>
	/// This is the main type for your game
	/// </summary>
	public class StarterGame : Game, IGame
	{

#if DEBUG
		private SampleGrid grid;
#endif
		CameraManager cameraManager;
		PlayerComponent player;
		SceneDefinition definition = new SceneDefinition();
		
#if WINDOWS||XBOX
		ParticleMaster particles;
#endif
		public StarterGame()
		{
			SharedResources.OnCreate(this);
#if WINDOWS||XBOX
			particles = new ParticleMaster();
			this.Components.Add(particles);
#endif
			cameraManager = new CameraManager();
			player = new PlayerComponent(new SnowmanToken());
			this.Components.Add(cameraManager);
			this.Components.Add(player);
			this.Components.Add(new DrawOrderManager());
			
#if DEBUG
			this.Components.Add(new FrameRateCounter(this));
#endif
#if WINDOWS_PHONE
			Content.RootDirectory = "Content";
#endif
#if  WINDOWS
			Content.RootDirectory = "GameContent(HiDef)";
#endif

#if XBOX 
			Content.RootDirectory = "Content360(HiDef)";
#endif
		}

		/// <summary>
		/// Allows the game to perform any initialization it needs to before starting to run.
		/// This is where it can query for any required services and load any non-graphic
		/// related content.  Calling base.Initialize will enumerate through any components
		/// and initialize them as well.
		/// </summary>
		protected override void Initialize()
		{
#if DEBUG
			DebugShapeRenderer.Initialize(this.GraphicsDevice);
#endif

			SharedResources.OnInitialize(this);
			// TODO: Add your initialization logic here



			base.Initialize();
		}

		/// <summary>
		/// LoadContent will be called once per game and is the place to load
		/// all of your content.
		/// </summary>
		protected override void LoadContent()
		{
			SharedResources.OnLoadContent(this);

#if WINDOWS_PHONE
			cameraManager.Add(new FirstPersonCamera(player.Player, Vector3.Backward));

#endif
#if XBOX || WINDOWS
			
			this.definition = Content.Load<SceneDefinition>("Scene");

			SharedResources.BackgroundColor = definition.Game.BackgroundColor;

			player.Player.Position = definition.Player.Position;

			foreach (var item in definition.Cameras)
			{
				try
				{
					switch (item.Type)
					{
						case eCameraType.FirstPerson:
							Vector3? vec = (item.Info as Vector3?);
							cameraManager.Add(new FirstPersonCamera(player.Player, vec.Value));
							break;
						case eCameraType.ThirdPerson:
							float? dist = (item.Info as float?);
							cameraManager.Add(new ThirdPersonCamera(player.Player, dist.Value));
							break;
						default:
							throw new SceneDefinitionException(String.Format("Camera type Undefined:{0}", item.Type));
					}
				}
				catch (SceneDefinitionException e)
				{
					throw e;
				}
				catch (Exception e)
				{
					throw new SceneDefinitionException(String.Format("Probably casting value wrong:{0}", item.Type), e);
				}
			}
#endif
#if XBOX || WINDOWS
			particles.pitParticles.Position = definition.Particles.CampFirePosition;
			particles.pitParticles.Radius = definition.Particles.CampFireRadius;
			if (definition.Particles.LightRadius.HasValue)
			{
				LightingManager.LightSources.Add(new FlickeringFire(definition.Particles.LightRadius.Value, particles.pitParticles));
			}
#endif
			foreach (var item in definition.NDModels)
			{

				DrawOrderManager.AddNormalDiffuseModel(item.Name, item.AssetPath, item.NormalPath, item.ColorPath, item.Instances.ToArray(), item.DrawOrderSuggestion);
			}

#if DEBUG

			//Set up the reference grid
			grid = new SampleGrid();
			grid.GridColor = Color.LimeGreen;
			grid.GridScale = 1.0f;
			grid.GridSize = 32;
			grid.LoadGraphicsContent();
			//Set the grid to draw on the x/z plane around the origin
			grid.WorldMatrix = Matrix.Identity;
#endif

		}
		
#if DEBUG && WINDOWS
		public void Save(string filename)
		{
			XmlWriterSettings settings = new XmlWriterSettings();
			settings.Indent = true;

			using (XmlWriter writer = XmlWriter.Create(filename, settings))
			{
				IntermediateSerializer.Serialize(writer, this.definition, null);
			}
		}
#endif
		/// <summary>
		/// UnloadContent will be called once per game and is the place to unload
		/// all content.
		/// </summary>
		protected override void UnloadContent()
		{

			SharedResources.OnUnLoadContent(this);
			// TODO: Unload any non ContentManager content here
		}

		/// <summary>
		/// Allows the game to run logic such as updating the world,
		/// checking for collisions, gathering input, and playing audio.
		/// </summary>
		/// <param name="gameTime">Provides a snapshot of timing values.</param>
		protected override void Update(GameTime gameTime)
		{
			SharedResources.OnBeginUpdate(gameTime);

			SharedResources.OnUpdate(this);
			LightingManager.Update();
			
#if DEBUG && WINDOWS
			if (SharedResources.KeyboardPressedAndReleased(Keys.S))
			{ Save("Scene.xml"); }
#endif

			base.Update(gameTime);
			SharedResources.OnEndUpdate();
		}

		/// <summary>
		/// This is called when the game should draw itself.
		/// </summary>
		/// <param name="gameTime">Provides a snapshot of timing values.</param>
		protected override void Draw(GameTime gameTime)
		{
			SharedResources.Draw(this);
			var bounding = DrawOrderManager.GetBoundingBoxes(eModelType.Cube);
			foreach (var box in bounding)
			{
				DebugShapeRenderer.AddBoundingBox(box, Color.Violet);
			}

			bounding = DrawOrderManager.GetBoundingBoxes(eModelType.Instanced);
			foreach (var box in bounding)
			{
				DebugShapeRenderer.AddBoundingBox(box, Color.Black);
			}

			bounding = DrawOrderManager.GetBoundingBoxes(eModelType.Simple);
			foreach (var box in bounding)
			{
				DebugShapeRenderer.AddBoundingBox(box, Color.DarkOliveGreen);
			}

			SharedResources.ResetGraphicsDevice();

			base.Draw(gameTime);


			SharedResources.ResetGraphicsDevice();


			SharedResources.SpriteBatch.Begin();

#if DEBUG
#if WINDOWS||XBOX
			SharedResources.SpriteBatch.DrawString(SharedResources.DebugFont, "Light Position" + LightingManager.LightSources[0].LightSourcePosition.ToString(), new Vector2(50, 120), Color.WhiteSmoke);
#endif
			SharedResources.SpriteBatch.DrawString(SharedResources.DebugFont, "Player Position" + player.Player.Position.ToString(), new Vector2(50, 100), Color.WhiteSmoke);
			//SharedResources.SpriteBatch.DrawString(SharedResources.DebugFont, "Debug", new Vector2(50, 50), Color.Black);
#else
			//SharedResources.SpriteBatch.DrawString(SharedResources.DebugFont, "Release", new Vector2(50,50), Color.Black);
#endif
			SharedResources.SpriteBatch.End();
		}

		public Game xnaGame
		{
			get
			{
				return this;
			}
			set
			{
				throw new NotImplementedException();
			}
		}

		public void CreateAssets()
		{
		}

		public bool IsButtonDown(Buttons button, PlayerIndex? controllingPlayer)
		{
			return (SharedResources.CurrentGamePadState.IsButtonDown(button));
		}

		public Vector2 LeftThumbstick(PlayerIndex? controllingPlayer)
		{
			return SharedResources.CurrentGamePadState.ThumbSticks.Left;
		}

	}
}
